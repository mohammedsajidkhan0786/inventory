<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('home', 'Home::index');
$routes->get('create_ticket', 'Home::submitTicket');


$routes->get('/install', 'InstallController::index');
$routes->get('/install/step1', 'InstallController::step1');
$routes->get('/install/step2', 'InstallController::step2');
$routes->get('/install/step3', 'InstallController::step3');
$routes->get('/install/finalize', 'InstallController::finalize');
$routes->post('/install/configureDatabase', 'InstallController::configureDatabase');
$routes->get('/auth/login', 'Auth::login');
$routes->post('/auth/login', 'Auth::login');
$routes->get('/auth/logout', 'Auth::logout');
$routes->get('dashboard', 'DashboardController::index', ['filter' => 'auth']); // Apply the 'auth' filter
$routes->get('canned_replies', 'DashboardController::canned_replies', ['filter' => 'auth']); // Apply the 'auth' filter
$routes->get('canned_replies/get/(:num)', 'DashboardController::getCannedReply/$1', ['filter' => 'auth']);
$routes->get('ticket_replies/get/(:num)', 'DashboardController::getticketReply/$1', ['filter' => 'auth']);
$routes->post('canned_add', 'DashboardController::canned_replies_add', ['filter' => 'auth']);
$routes->get('tickets/all', 'DashboardController::TicketAll', ['filter' => 'auth']);
$routes->get('tickets/opened', 'DashboardController::TicketOpened', ['filter' => 'auth']);
$routes->get('tickets/closed', 'DashboardController::Ticketclosed', ['filter' => 'auth']);
$routes->get('tickets/assigned', 'DashboardController::Ticketassigned', ['filter' => 'auth']);
$routes->get('tickets/create_tickets', 'DashboardController::TicketCreate', ['filter' => 'auth']);

$routes->get('language/switch/(:segment)', 'Language::switch/$1');
