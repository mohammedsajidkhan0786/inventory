<?= $this->extend("admin/backend/layout/pages-layout"); ?>


<?= $this->section("content") ?>

<div class=" mx-auto">
    <div class="row">
        <div class="col-lg-8 col-md-8 col-12 mx-auto">
            <div class="card z-index-0  mt-8">

                <div class="card-body">

                    <div class=" pb-0 px-3">
                        <h6 class="mb-0">Create Ticket</h6>
                    </div>
                    <div class=" pt-4 p-3">
                        <!-- <form role="form" class="text-start"> -->
                        <form action="#" method="POST" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <div class="  my-3">
                                            <label for="subject" class="form-label">Subject <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control border">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <div class=" my-3">
                                            <label for="priority" class="form-label">Priority <span class="text-danger">*</span></label>
                                            <select class="form-select" id="priority" name="priority" required>
                                                <option value="">Choose Priority</option>
                                                <option value="Low">Low</option>
                                                <option value="Medium">Medium</option>
                                                <option value="High">High</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>


                                <!-- Department -->
                                <div class="mb-3">
                                    <label for="department" class="form-label">Department <span class="text-danger">*</span></label>
                                    <select class="form-select" id="department" name="department" required>
                                        <option value="">Select Department</option>
                                        <option value="Support">Support</option>
                                        <option value="Sales">Sales</option>
                                        <option value="Billing">Billing</option>
                                    </select>
                                </div>
                                <!-- Message -->
                                <div class="mb-3">
                                    <label for="message" class="form-label">Message <span class="text-danger">*</span></label>
                                    <textarea class="form-control border" id="message" name="message" rows="4" required></textarea>
                                </div>

                                <!-- Email and Retype Email -->
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="email" class="form-label">Email Address <span class="text-danger">*</span></label>
                                            <input type="email" class="form-control border" id="email" name="email" required>
                                            <p class="p-2 bg-light border border-top-0 shadow-sm rounded text-center small"><i class="fas fa-info-circle me-1"></i> Please make sure that it's accessible as this will be used to verify the ticket submission and receive its notifications.</p>

                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="retype_email" class="form-label">Retype Email Address <span class="text-danger">*</span></label>
                                            <input type="email" class="form-control border" id="retype_email" name="retype_email" required>
                                        </div>
                                    </div>
                                </div>
                                <!-- Attachments -->
                                <div class="mb-3">
                                    <label for="attachments" class="form-label">Attach File(s)</label>
                                    <input type="file" class="form-control border" id="attachments" name="attachments[]" multiple>
                                    <small class="form-text text-muted">Only JPEG, JPG, PNG, BMP, GIF, PDF, CSV, XLS, and XLSX formats are allowed.</small>
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn bg-gradient-primary w-100 my-4 mb-2">Sign in</button>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <br><br><br><br><br><br><br><br><br><br><br>
</div>




<?= $this->endsection() ?>