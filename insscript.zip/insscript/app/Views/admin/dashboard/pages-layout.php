<!DOCTYPE html>
<html lang="<?= session()->get('language') ?>" dir="<?= $direction ?>">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/img/favicon.png">
    <title>
        Ticket System
    </title>
    <!--     Fonts and icons     -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
    <!-- Nucleo Icons -->
    <link href="../assets/css/nucleo-icons.css" rel="stylesheet" />
    <link href="../assets/css/nucleo-svg.css" rel="stylesheet" />
    <!-- Font Awesome Icons -->
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
    <!-- CSS Files -->
    <?php if (session()->get('language') == 'ar'): ?>
        <link rel="stylesheet" href="<?= base_url('assets/css/material-dashboard-rtl.css?v=3.1.0') ?>">
    <?php else: ?>
        <link rel="stylesheet" href="<?= base_url('assets/css/material-dashboard.css?v=3.1.0') ?>">
    <?php endif; ?>
    <?= $this->renderSection("stylesheet"); ?>

    <style>
        /* Dropdown container */
        .dropdown {
            position: relative;
            display: inline-block;
        }

        /* Dropdown content (hidden by default) */
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: white;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
            min-width: 160px;
            z-index: 1;
            padding: 10px;
            border-radius: 5px;
        }

        /* Show the dropdown menu when hovering over the container */
        .dropdown:hover .dropdown-content {
            display: block;
        }

        /* Links inside the dropdown */
        .dropdown-content a {
            text-decoration: none;
            display: block;
            padding: 10px;
            color: black;
            font-size: 16px;
        }

        /* Change background on hover */
        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }

        /* Styling for selected language */
        .dropdown-content .selected {
            color: green;
            font-weight: bold;
        }

        /* Add checkmark for selected language */
        .dropdown-content .selected::before {
            content: '✔';
            color: green;
            margin-right: 10px;
        }

        /* Style the button that triggers the dropdown */
        .dropdown button {
            background-color: #007bff;
            color: white;
            padding: 5px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        /* .dropdown button:hover {
            background-color: #0056b3;
        } */
    </style>
    <style>
        .badge-dot {
            height: 10px;
            width: 10px;
            border-radius: 50%;
            display: inline-block;
        }

        .bg-success {
            background-color: #28a745;
            /* Green color for online */
        }

        .bg-secondary {
            background-color: #6c757d;
            /* Gray color for offline */
        }

        hr {
            height: 1px;
            color: #ed1d61;
            background: #ed1d61;
            font-size: 0;
            border: 0;
        }
    </style>


</head>

<body class="g-sidenav-show  bg-gray-200">
    <!-- aside Navbar -->
    <?php include('inc/aside.php') ?>
    <!-- End aside Navbar -->
    <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
        <!-- Navbar -->
        <?php include('inc/nav.php') ?>
        <!-- End Navbar -->
        <?= $this->renderSection('content') ?>

        <?php include('inc/footer.php') ?>
    </main>
    <!-- Color change  -->
    <?php include('inc/colorchange.php') ?>

    <!--End  Color change  -->

    <!--   Core JS Files   -->
    <script src="<?= base_url() . 'assets/js/core/popper.min.js' ?>"></script>
    <script src="<?= base_url() . 'assets/js/core/bootstrap.min.js' ?>"></script>
    <script src="<?= base_url() . 'assets/js/plugins/perfect-scrollbar.min.js' ?>"></script>
    <script src="<?= base_url() . 'assets/js/plugins/smooth-scrollbar.min.js' ?>"></script>

    <script>
        var win = navigator.platform.indexOf('Win') > -1;
        if (win && document.querySelector('#sidenav-scrollbar')) {
            var options = {
                damping: '0.5'
            }
            Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
        }
    </script>

    <script src="<?= base_url() . 'assets/js/material-dashboard.min.js?v=3.1.0' ?>"></script>


    <?= $this->renderSection("script"); ?>
</body>

</html>