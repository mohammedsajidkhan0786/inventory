<?= $this->extend("admin/dashboard/pages-layout"); ?>


<?= $this->section("content") ?>






<?= $this->endsection() ?>