<?= $this->extend("admin/dashboard/pages-layout"); ?>


<?= $this->section("content") ?>


<div class="col-md-12 mb-lg-0 mb-4">
    <div class="card">


        <!-- /.row -->
        <div class="row">
            <div class="col-md-12">
                <form class="form" action="" method="post" enctype="multipart/form-data" data-csrf="manual">
                    <div class="response-message"></div>
                    <input type="hidden" name="z_csrf" value="589ecde9f4960a3caa87106720de1902">

                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title">Create Ticket</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="subject" class="bmd-label-floating">Subject <span class="required">*</span></label>
                                        <input type="text" id="subject" class="form-control border" name="subject" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="priority" class="bmd-label-floating">Priority <span class="required">*</span></label>
                                        <select id="priority" class="form-control border selectpicker form-select" name="priority" required>
                                            <option value=""></option>
                                            <option value="low">Low</option>
                                            <option value="medium">Medium</option>
                                            <option value="high">High</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="department" class="bmd-label-floating">Department <span class="required">*</span></label>
                                        <select id="department" class="form-control border selectpicker form-select" name="department" required>
                                            <option value=""></option>
                                            <option value="3">Jeddah Department</option>
                                            <option value="2">Riyadh Department</option>
                                            <option value="1">General Inquiries</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="customer" class="bmd-label-floating">Customer <span class="required">*</span></label>
                                        <select id="customer" class="form-control border selectpicker form-select" name="customer" required>
                                            <option value=""></option>
                                            <option value="6">Bookmytrek Riyadh ( bookmytrekriyadh )</option>
                                            <option value="5">Tamexjeddah Manager ( tamexjeddahmanager )</option>
                                            <option value="4">Tamexriyadh Manager ( tamexriyadhmanager )</option>
                                            <option value="3">Tamexjeddah User ( tamexjeddahuser )</option>
                                            <option value="2">Tamexriyadh User ( tamexriyadhuser )</option>
                                            <option value="1">Super Admin ( superadmin )</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="message" class="bmd-label-floating">Message <span class="required">*</span></label>
                                <textarea class="form-control border" id="message" name="message" rows="6" required></textarea>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">

                                    <div class="mb-3">
                                        <label for="attachments" class="form-label">Attach File(s)</label>
                                        <input type="file" class="form-control border " id="attachments" name="attachments[]" multiple>
                                        <small class="form-text text-muted">Only JPEG, JPG, PNG, BMP, GIF, PDF, CSV, XLS, and XLSX formats are allowed.</small>
                                    </div>

                                </div>
                            </div>
                        </div>

                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary pull-right">
                                <i class="material-icons">check_circle</i> Submit
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- /.row -->
    </div>
</div>





<?= $this->endsection() ?>