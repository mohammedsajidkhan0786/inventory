<aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3   bg-gradient-dark" id="sidenav-main">
    <div class="sidenav-header">
        <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
        <a class="navbar-brand m-0" href="  " target="_blank">
            <img src="../assets/img/logo-ct.png" class="navbar-brand-img h-100" alt="main_logo">
            <span class="ms-1 font-weight-bold text-white">Tamex</span>
        </a>

    </div>
    <hr class="horizontal light mt-0 mb-2">
    <div class="collapse navbar-collapse  w-auto " id="sidenav-collapse-main">
        <ul class="navbar-nav">
            <?php if (session()->get('isLoggedIn')): ?>
                <!-- Display different options based on the user's role -->
                <?php if (session()->get('role') == 'super_admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link text-white">
                            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="material-icons opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1"></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white <?= (uri_string() == 'dashboard') ? 'active bg-gradient-primary' : '' ?>" href="<?= base_url('dashboard') ?>">
                            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="material-icons opacity-10">dashboard</i>
                            </div>
                            <span class="nav-link-text ms-1">Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white <?= (uri_string() == 'canned_replies') ? 'active bg-gradient-primary' : '' ?>" href="<?= base_url('canned_replies') ?>">
                            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="fas fa-comment-dots nav-icon opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Canned Replies</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white <?= (uri_string() == 'tickets/all') ? 'active bg-gradient-primary' : '' ?>" href="<?= base_url('tickets/all') ?>">
                            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="fas fa-list-ul nav-icon opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">All Ticket</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link text-white <?= (uri_string() == 'tickets/opened') ? 'active bg-gradient-primary' : '' ?>" href="<?= base_url('tickets/opened') ?>">
                            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="fas fa-folder-open nav-icon nav-icon opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Open Ticket</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link text-white <?= (uri_string() == 'tickets/closed') ? 'active bg-gradient-primary' : '' ?>" href="<?= base_url('tickets/closed') ?>">
                            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="fas fa-folder nav-icon nav-icon opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">closed Ticket</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link text-white <?= (uri_string() == 'tickets/assigned') ? 'active bg-gradient-primary' : '' ?>" href="<?= base_url('tickets/assigned') ?>">
                            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="fas fa-user nav-icon nav-icon opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Assigned Ticket</span>
                        </a>
                    </li>

                <?php endif; ?>
            <?php else: ?>
            <?php endif; ?>
        </ul>

    </div>

</aside>