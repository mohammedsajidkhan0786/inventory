<footer class="footer py-4  ">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
                <div class="copyright text-center text-sm text-muted text-lg-start">
                    © <script>
                        document.write(new Date().getFullYear())
                    </script>,
                    made with <i class="fa fa-heart"></i> by
                    <a href="#" class="font-weight-bold" target="_blank">Tamex </a>
                    for a better web.
                </div>
            </div>
            <div class="col-lg-6">
                <ul class="nav nav-footer justify-content-center justify-content-lg-end">

                    <ul class="dropdown">
                        <button class=" mb-3  bg-gradient-dark dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            Language
                        </button>
                        <ul class="dropdown-menu dropdown-content">
                            <li><a class="dropdown-item <?= session()->get('language') == 'en' ? 'selected' : '' ?>" href="<?= site_url('language/switch/en') ?>">English</a></li>
                            <li><a class="dropdown-item <?= session()->get('language') == 'ar' ? 'selected' : '' ?>" href="<?= site_url('language/switch/ar') ?>">Arabic</a></li>
                        </ul>
                    </ul>
                </ul>
            </div>
        </div>
    </div>
</footer>