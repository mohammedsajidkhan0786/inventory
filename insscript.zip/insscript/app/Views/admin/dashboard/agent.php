<?= $this->extend("admin/backend/layout/pages-layout"); ?>


<?= $this->section("content") ?>






<?= $this->endsection() ?>