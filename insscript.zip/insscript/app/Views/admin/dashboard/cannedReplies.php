<?= $this->extend("admin/dashboard/pages-layout"); ?>


<?= $this->section("content") ?>

<style>
    /* Small green button */
    .btn-sms {
        padding: 4px 6px;
        font-size: 8px;
    }

    .btn-success {
        background-color: #28a745;
        color: white;
    }

    .btn-success:disabled {
        background-color: #6c757d;
    }

    /* Modal styling */
    .modal {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        display: none;
        justify-content: center;
        align-items: center;
    }


    .modal-header,
    .modal-footer {
        padding: 16px;
        border-bottom: 1px solid #dee2e6;
    }

    .modal-footer {
        border-top: 1px solid #dee2e6;
    }

    .close-modal {
        cursor: pointer;
        background: none;
        border: none;
        font-size: 24px;
        font-weight: bold;
        color: #333;
        float: right;
    }
</style>

<div class="col-md-12 mb-lg-0 mb-4">
    <div class="card mt-4">
        <div class="card-header pb-0 p-3">
            <div class="row">
                <div class="col-6 d-flex align-items-center">
                    <h6 class="mb-0">Canned Replies</h6>
                </div>
                <div class="col-6 text-end">
                    <?php //if (!empty($canned_replies)): 
                    ?>
                    <!-- Display a single "Add New Card" button -->
                    <button class="btn bg-gradient-dark mb-0 open-modal3"><i class="material-icons text-sm">add</i>&nbsp;&nbsp;Add Canned Reply</button>
                    <?php //endif; 
                    ?>
                </div>

            </div>
        </div>
        <div class="card-body p-3">
            <div class="table-responsive p-0">
                <!-- <table class="table align-items-center mb-0">
                    <thead>
                        <tr>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Author</th>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Function</th>
                            <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Status</th>
                            <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Employed</th>
                            <th class="text-secondary opacity-7"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <div class="d-flex px-2 py-1">
                                    <div>
                                        <img src="../assets/img/team-2.jpg" class="avatar avatar-sm me-3 border-radius-lg" alt="user1">
                                    </div>
                                    <div class="d-flex flex-column justify-content-center">
                                        <h6 class="mb-0 text-sm">John Michael</h6>
                                        <p class="text-xs text-secondary mb-0">john@creative-tim.com</p>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <p class="text-xs font-weight-bold mb-0">Manager</p>
                                <p class="text-xs text-secondary mb-0">Organization</p>
                            </td>
                            <td class="align-middle text-center text-sm">
                                <span class="badge badge-sm bg-gradient-success">Online</span>
                            </td>
                            <td class="align-middle text-center">
                                <span class="text-secondary text-xs font-weight-bold">23/04/18</span>
                            </td>
                            <td class="align-middle">
                                <a href="javascript:;" class="text-secondary font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user">
                                    Edit
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="d-flex px-2 py-1">
                                    <div>
                                        <img src="../assets/img/team-3.jpg" class="avatar avatar-sm me-3 border-radius-lg" alt="user2">
                                    </div>
                                    <div class="d-flex flex-column justify-content-center">
                                        <h6 class="mb-0 text-sm">Alexa Liras</h6>
                                        <p class="text-xs text-secondary mb-0">alexa@creative-tim.com</p>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <p class="text-xs font-weight-bold mb-0">Programator</p>
                                <p class="text-xs text-secondary mb-0">Developer</p>
                            </td>
                            <td class="align-middle text-center text-sm">
                                <span class="badge badge-sm bg-gradient-secondary">Offline</span>
                            </td>
                            <td class="align-middle text-center">
                                <span class="text-secondary text-xs font-weight-bold">11/01/19</span>
                            </td>
                            <td class="align-middle">
                                <a href="javascript:;" class="text-secondary font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user">
                                    Edit
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="d-flex px-2 py-1">
                                    <div>
                                        <img src="../assets/img/team-4.jpg" class="avatar avatar-sm me-3 border-radius-lg" alt="user3">
                                    </div>
                                    <div class="d-flex flex-column justify-content-center">
                                        <h6 class="mb-0 text-sm">Laurent Perrier</h6>
                                        <p class="text-xs text-secondary mb-0">laurent@creative-tim.com</p>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <p class="text-xs font-weight-bold mb-0">Executive</p>
                                <p class="text-xs text-secondary mb-0">Projects</p>
                            </td>
                            <td class="align-middle text-center text-sm">
                                <span class="badge badge-sm bg-gradient-success">Online</span>
                            </td>
                            <td class="align-middle text-center">
                                <span class="text-secondary text-xs font-weight-bold">19/09/17</span>
                            </td>
                            <td class="align-middle">
                                <a href="javascript:;" class="text-secondary font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user">
                                    Edit
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="d-flex px-2 py-1">
                                    <div>
                                        <img src="../assets/img/team-3.jpg" class="avatar avatar-sm me-3 border-radius-lg" alt="user4">
                                    </div>
                                    <div class="d-flex flex-column justify-content-center">
                                        <h6 class="mb-0 text-sm">Michael Levi</h6>
                                        <p class="text-xs text-secondary mb-0">michael@creative-tim.com</p>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <p class="text-xs font-weight-bold mb-0">Programator</p>
                                <p class="text-xs text-secondary mb-0">Developer</p>
                            </td>
                            <td class="align-middle text-center text-sm">
                                <span class="badge badge-sm bg-gradient-success">Online</span>
                            </td>
                            <td class="align-middle text-center">
                                <span class="text-secondary text-xs font-weight-bold">24/12/08</span>
                            </td>
                            <td class="align-middle">
                                <a href="javascript:;" class="text-secondary font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user">
                                    Edit
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="d-flex px-2 py-1">
                                    <div>
                                        <img src="../assets/img/team-2.jpg" class="avatar avatar-sm me-3 border-radius-lg" alt="user5">
                                    </div>
                                    <div class="d-flex flex-column justify-content-center">
                                        <h6 class="mb-0 text-sm">Richard Gran</h6>
                                        <p class="text-xs text-secondary mb-0">richard@creative-tim.com</p>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <p class="text-xs font-weight-bold mb-0">Manager</p>
                                <p class="text-xs text-secondary mb-0">Executive</p>
                            </td>
                            <td class="align-middle text-center text-sm">
                                <span class="badge badge-sm bg-gradient-secondary">Offline</span>
                            </td>
                            <td class="align-middle text-center">
                                <span class="text-secondary text-xs font-weight-bold">04/10/21</span>
                            </td>
                            <td class="align-middle">
                                <a href="javascript:;" class="text-secondary font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user">
                                    Edit
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="d-flex px-2 py-1">
                                    <div>
                                        <img src="../assets/img/team-4.jpg" class="avatar avatar-sm me-3 border-radius-lg" alt="user6">
                                    </div>
                                    <div class="d-flex flex-column justify-content-center">
                                        <h6 class="mb-0 text-sm">Miriam Eric</h6>
                                        <p class="text-xs text-secondary mb-0">miriam@creative-tim.com</p>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <p class="text-xs font-weight-bold mb-0">Programator</p>
                                <p class="text-xs text-secondary mb-0">Developer</p>
                            </td>
                            <td class="align-middle text-center text-sm">
                                <span class="badge badge-sm bg-gradient-secondary">Offline</span>
                            </td>
                            <td class="align-middle text-center">
                                <span class="text-secondary text-xs font-weight-bold">14/09/20</span>
                            </td>
                            <td class="align-middle">
                                <a href="javascript:;" class="text-secondary font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user">
                                    Edit
                                </a>
                            </td>
                        </tr>
                    </tbody>
                </table> -->
                <!-- Material Dashboard CSS -->


                <!-- Main Container -->
                <div class="container">


                    <table class="table align-items-center mb-0">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Subject</th>
                                <th>Message</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($canned_replies)): ?>
                                <?php foreach ($canned_replies as $reply): ?>
                                    <tr>
                                        <td><?= $reply['id'] ?></td>
                                        <td><?= $reply['subject'] ?></td>
                                        <td><?= substr($reply['message'], 0, 29) ?>...<button class="btn btn-sms btn-success open-modal1" data-id="<?= $reply['id'] ?>">Read More</button></td>

                                        <!-- Modal Trigger Button -->


                                        <td>
                                            <a href="<?= base_url('canned_replies/edit/' . $reply['id']) ?>" class="btn btn-primary"><i class="fas fa-edit get-data-tool-c"></i></a>
                                            <a href="<?= base_url('canned_replies/delete/' . $reply['id']) ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this?')"><i class="fas fa-trash tool-c"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4">No canned replies found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Modal Structure -->
                <div id="materialModal" class="modal">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Canned Reply</h5>
                                <button type="button" class="close-modal" aria-label="Close">&times;</button>
                            </div>
                            <div class="modal-body">
                                <p id="modal-message">Loading...</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger close-modal"><i class="fas fa-close">X</i></button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- add canned -->
                <!-- Trigger Button for Modal -->
                <!-- Example of a button with a correct data-id -->



                <!-- Modal Structure -->
                <div id="addCannedReplyModal" class="modal" style="display: none;">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Add Canned Reply</h5>
                                <button type="button" class="close-modal">&times;</button>
                            </div>
                            <div class="modal-body">
                                <form id="cannedReplyForm">
                                    <div class="mb-3">
                                        <label for="subject" class="form-label">Subject <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control border" id="subject" name="subject">
                                    </div>
                                    <div class="mb-3">
                                        <label for="message" class="form-label">Message <span class="text-danger">*</span></label>
                                        <textarea class="form-control border" id="message" name="message" rows="4"></textarea>
                                    </div>

                                    <!-- Placeholders Info -->
                                    <div class="table-responsive">
                                        <table class="table table-bordered">
                                            <tbody>
                                                <tr>
                                                    <td>Requester’s Name</td>
                                                    <td>{REQUESTER_NAME}</td>
                                                </tr>
                                                <tr>
                                                    <td>Logged-in Agent/Ticket Manager</td>
                                                    <td>{AGENT_NAME}</td>
                                                </tr>
                                                <tr>
                                                    <td>Ticket/Chat Subject</td>
                                                    <td>{SUBJECT}</td>
                                                </tr>
                                                <tr>
                                                    <td>Website Name</td>
                                                    <td>{SITE_NAME}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <!-- <button type="button" class="btn-sm btn-danger  close-modal">Close</button> -->
                                <button type="submit" form="cannedReplyForm" class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- endadd canned -->

                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        // Open modal when trigger button is clicked
                        document.querySelectorAll('.open-modal1').forEach(button => {
                            button.addEventListener('click', function() {
                                var replyId = this.getAttribute('data-id');
                                var originalText = this.textContent;

                                // Show loading state on button
                                this.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...';
                                this.disabled = true;

                                // Fetch the content dynamically using AJAX (fetch API)
                                fetch('<?= base_url('canned_replies/get/') ?>' + replyId)
                                    .then(response => response.json())
                                    .then(data => {
                                        // Set modal content
                                        document.getElementById('modal-message').textContent = data.message;

                                        // Remove loading state
                                        button.textContent = originalText;
                                        button.disabled = false;

                                        // Show modal
                                        document.getElementById('materialModal').style.display = 'block';
                                    })
                                    .catch(error => {
                                        document.getElementById('modal-message').textContent = 'Error loading message';

                                        // Remove loading state
                                        button.textContent = originalText;
                                        button.disabled = false;
                                    });
                            });
                        });

                        // Close modal when close button is clicked
                        document.querySelectorAll('.close-modal').forEach(button => {
                            button.addEventListener('click', function() {
                                document.getElementById('materialModal').style.display = 'none';
                            });
                        });
                    });
                </script>

                <!-- <script>
                    document.getElementById('cannedReplyForm').addEventListener('submit', function(event) {
                        event.preventDefault();

                        // Gather form data
                        const formData = new FormData(this);

                        // Send AJAX request
                        fetch('<?= base_url('canned_replies/add') ?>', {
                                method: 'POST',
                                body: formData,
                            })
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    alert('Canned Reply added successfully!');
                                    // You can close the modal and clear the form here
                                    document.getElementById('addCannedReplyModal').style.display = 'none';
                                } else {
                                    alert('An error occurred. Please try again.');
                                }
                            })
                            .catch(error => {
                                console.error('Error:', error);
                            });
                    });
                </script> -->
                <!-- <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        // Open modal when trigger button is clicked
                        document.querySelector('.open-modal3').addEventListener('click', function() {
                            document.getElementById('addCannedReplyModal').style.display = 'block';
                        });

                        // Close modal when close button is clicked
                        document.querySelectorAll('.close-modal').forEach(button => {
                            button.addEventListener('click', function() {
                                document.getElementById('addCannedReplyModal').style.display = 'none';
                            });
                        });

                        // Form submission event listener
                        document.getElementById('cannedReplyForm').addEventListener('submit', function(event) {
                            event.preventDefault(); // Prevent form from submitting traditionally

                            // Gather form data
                            const formData = new FormData(this);

                            // Send AJAX request
                            fetch('<?= base_url('canned_add') ?>', {
                                    method: 'POST',
                                    body: formData,
                                })
                                .then(response => response.json())
                                .then(data => {
                                    if (data.success) {
                                        alert('Canned Reply added successfully!');
                                        // You can close the modal and clear the form here
                                        document.getElementById('addCannedReplyModal').style.display = 'none';
                                        document.getElementById('cannedReplyForm').reset();
                                    } else {
                                        alert('An error occurred. Please try again.');
                                    }
                                })
                                .catch(error => {
                                    console.error('Error:', error);
                                });
                        });
                    });
                </script> -->

                <!-- <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        // Open modal when trigger button is clicked
                        document.querySelectorAll('.open-modal').forEach(button => {
                            button.addEventListener('click', function() {
                                var replyId = this.getAttribute('data-id');

                                // Check if replyId is valid
                                if (!replyId) {
                                    console.error('No reply ID found.');
                                    return; // Prevent further execution
                                }

                                // Show loading spinner or text
                                document.getElementById('modal-message').textContent = 'Loading...';

                                // Fetch the content dynamically using AJAX
                                fetch('<?= base_url('canned_replies/get/') ?>' + replyId)
                                    .then(response => response.json())
                                    .then(data => {
                                        // Set modal content
                                        document.getElementById('modal-message').textContent = data.message;
                                    })
                                    .catch(error => {
                                        console.error('Error fetching reply:', error);
                                        document.getElementById('modal-message').textContent = 'Error loading message';
                                    });

                                // Show modal
                                document.getElementById('addCannedReplyModal').style.display = 'block';
                            });
                        });

                        // Close modal when close button is clicked
                        document.querySelectorAll('.close-modal').forEach(button => {
                            button.addEventListener('click', function() {
                                document.getElementById('addCannedReplyModal').style.display = 'none';
                            });
                        });
                    });
                </script> -->
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        // Open modal when trigger button is clicked
                        document.querySelector('.open-modal3').addEventListener('click', function() {
                            document.getElementById('addCannedReplyModal').style.display = 'block';
                        });

                        // Close modal when close button is clicked
                        document.querySelectorAll('.close-modal').forEach(button => {
                            button.addEventListener('click', function() {
                                document.getElementById('addCannedReplyModal').style.display = 'none';
                            });
                        });

                        // Handle form submission via AJAX
                        document.getElementById('cannedReplyForm').addEventListener('submit', function(event) {
                            event.preventDefault(); // Prevent default form submission

                            const formData = new FormData(this); // Gather form data
                            // const csrfName = '<?= csrf_token() ?>'; // CSRF token name
                            //const csrfHash = '<?= csrf_hash() ?>'; // CSRF hash value


                            // AJAX request to send data
                            fetch('<?= base_url('canned_add') ?>', {
                                    method: 'POST',
                                    body: formData
                                })
                                .then(response => response.json())
                                .then(data => {
                                    if (data.success) {
                                        alert('Canned Reply added successfully!');
                                        document.getElementById('addCannedReplyModal').style.display = 'none'; // Close modal
                                        document.getElementById('cannedReplyForm').reset(); // Reset the form
                                    } else {
                                        alert('Error: ' + JSON.stringify(data.errors)); // Show validation errors
                                    }
                                })
                                .catch(error => {
                                    console.error('Request failed:', error);
                                    alert('An error occurred. Please try again.');
                                });
                        });
                    });
                </script>

            </div>
        </div>
    </div>
</div>
</div>
</div>




<?= $this->endsection() ?>