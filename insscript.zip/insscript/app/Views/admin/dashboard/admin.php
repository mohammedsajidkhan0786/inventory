<?= $this->extend("admin/dashboard/pages-layout"); ?>


<?= $this->section("content") ?>



<?php if (session()->get('role') === 'super_admin'): ?>

    <div class="row">
        <!-- Open Tickets Card -->
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
            <div class="card">
                <div class="card-header p-3 pt-2">
                    <div class="icon icon-lg icon-shape bg-gradient-dark shadow-dark text-center border-radius-xl mt-n4 position-absolute">
                        <i class="fas fa-folder-open opacity-10"></i>
                    </div>
                    <div class="text-end pt-1">
                        <p class="text-sm mb-0 text-capitalize">Open Ticket</p>
                        <h4 class="mb-0"><?= $open_tickets ?></h4>
                    </div>
                </div>
                <hr class="dark horizontal my-0">
                <div class="card-footer p-3">
                    <p class="mb-0"><span class="text-success text-sm font-weight-bolder">+55% </span>than last week</p>
                </div>
            </div>
        </div>

        <!-- Closed Tickets Card -->
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
            <div class="card">
                <div class="card-header p-3 pt-2">
                    <div class="icon icon-lg icon-shape bg-gradient-primary shadow-primary text-center border-radius-xl mt-n4 position-absolute">
                        <i class="material-icons opacity-10">folder</i>
                    </div>
                    <div class="text-end pt-1">
                        <p class="text-sm mb-0 text-capitalize">Closed Ticket</p>
                        <h4 class="mb-0"><?= $closed_tickets ?></h4>
                    </div>
                </div>
                <hr class="dark horizontal my-0">
                <div class="card-footer p-3">
                    <p class="mb-0"><span class="text-success text-sm font-weight-bolder">+3% </span>than last month</p>
                </div>
            </div>
        </div>

        <!-- All Tickets Card -->
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
            <div class="card">
                <div class="card-header p-3 pt-2">
                    <div class="icon icon-lg icon-shape bg-gradient-success shadow-success text-center border-radius-xl mt-n4 position-absolute">
                        <i class="material-icons opacity-10">list_alt</i>
                    </div>
                    <div class="text-end pt-1">
                        <p class="text-sm mb-0 text-capitalize">All Tickets</p>
                        <h4 class="mb-0"><?= $total_tickets ?></h4>
                    </div>
                </div>
                <hr class="dark horizontal my-0">
                <div class="card-footer p-3">
                    <p class="mb-0"><span class="text-danger text-sm font-weight-bolder">-2% </span>than yesterday</p>
                </div>
            </div>
        </div>

        <!-- Total Users Card -->
        <div class="col-xl-3 col-sm-6">
            <div class="card">
                <div class="card-header p-3 pt-2">
                    <div class="icon icon-lg icon-shape bg-gradient-info shadow-info text-center border-radius-xl mt-n4 position-absolute">
                        <i class="material-icons opacity-10">person</i>
                    </div>
                    <div class="text-end pt-1">
                        <p class="text-sm mb-0 text-capitalize">Total Users</p>
                        <h4 class="mb-0"><?= $total_users ?></h4>
                    </div>
                </div>
                <hr class="dark horizontal my-0">
                <div class="card-footer p-3">
                    <p class="mb-0"><span class="text-success text-sm font-weight-bolder">+5% </span>than yesterday</p>
                </div>
            </div>
        </div>
    </div>



    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-lg-8">
                <h4>Tickets Statistics</h4>
                <!-- Your ticket cards go here -->
                <div class="row mt-4">

                    <div class="col-lg-12 mt-4 mb-3">
                        <div class="card z-index-2 ">
                            <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2 bg-transparent">
                                <div class="bg-gradient-dark shadow-dark border-radius-lg py-3 pe-1">
                                    <div class="chart">
                                        <canvas id="ticketChart" class="chart-canvas" height="170"></canvas>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <h6 class="mb-0 ">Completed Tasks</h6>
                                <p class="text-sm ">Last Campaign Performance</p>
                                <hr class="dark horizontal">
                                <div class="d-flex ">
                                    <i class="material-icons text-sm my-auto me-1">schedule</i>
                                    <p class="mb-0 text-sm">just updated</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Recently Registered Users -->
            <div class="col-lg-4">
                <h4>Recently Registered</h4>
                <?php if (!empty($recent_users)): ?>
                    <div class="list-group">
                        <?php foreach ($recent_users as $user): ?>
                            <div class="list-group-item">
                                <div class="d-flex align-items-center">
                                    <div class="avatar">
                                        <img src="<?= base_url('assets/img/profileimg/default.png') ?>" alt="Avatar" class="rounded-circle" width="40">
                                        <!-- Show green dot only if the user is online -->

                                    </div>
                                    <?php if ($user['is_online']): ?>
                                        <span class="badge-dot bg-success ms-1"></span> <!-- Green dot if online -->
                                    <?php endif; ?>
                                    <div class="ms-3">
                                        <h6 class="mb-0"><?= esc($user['username']) ?></h6>
                                        <small class="text-muted"><?= esc($user['role_name']) ?></small> <!-- Show role by name -->

                                        <p class="small mb-0"><?= date('d/m/Y H:i:s', $user['registered_at']) ?></p>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p>No recently registered users found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>



<?php else: ?>

<?php endif; ?>

<script src="<?= base_url() . 'assets/js/plugins/chartjs.min.js' ?>"></script>
<script>
    var ctx = document.getElementById("ticketChart").getContext("2d");

    new Chart(ctx, {
        type: "line",
        data: {
            labels: <?= json_encode($months) ?>, // Months data from PHP
            datasets: [{
                label: "Tickets",
                tension: 0.4,
                borderWidth: 0,
                pointRadius: 5,
                pointBackgroundColor: "rgba(255, 255, 255, .8)",
                pointBorderColor: "transparent",
                borderColor: "rgba(75, 192, 192, 1)",
                borderWidth: 4,
                backgroundColor: "transparent",
                fill: true,
                data: <?= json_encode($ticketCounts) ?>, // Ticket counts from PHP
                maxBarThickness: 6
            }],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false,
                }
            },

            interaction: {
                intersect: false,
                mode: 'index',
            },
            scales: {
                y: {
                    grid: {
                        drawBorder: false,
                        display: true,
                        drawOnChartArea: true,
                        drawTicks: false,
                        borderDash: [5, 5],
                    },
                    ticks: {
                        display: true,
                        padding: 10,
                    }
                },
                x: {
                    grid: {
                        drawBorder: false,
                        display: false,
                        drawOnChartArea: false,
                        drawTicks: false,
                        borderDash: [5, 5]
                    },
                    ticks: {
                        display: true,
                        padding: 10,
                    }
                },
            },
        },
    });
</script>

<?= $this->endsection() ?>