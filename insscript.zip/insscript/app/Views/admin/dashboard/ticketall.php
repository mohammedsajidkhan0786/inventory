<?= $this->extend("admin/dashboard/pages-layout"); ?>


<?= $this->section("content") ?>
<style>
    /* Small green button */
    .btn-sms {
        padding: 4px 6px;
        font-size: 8px;
    }

    .btn-success {
        background-color: #28a745;
        color: white;
    }

    .btn-success:disabled {
        background-color: #6c757d;
    }

    /* Modal styling */
    .modal {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        display: none;
        justify-content: center;
        align-items: center;
    }


    .modal-header,
    .modal-footer {
        padding: 16px;
        border-bottom: 1px solid #dee2e6;
    }

    .modal-footer {
        border-top: 1px solid #dee2e6;
    }

    .close-modal {
        cursor: pointer;
        background: none;
        border: none;
        font-size: 24px;
        font-weight: bold;
        color: #333;
        float: right;
    }
</style>

<div class="col-md-12 mb-lg-0 mb-4">
    <div class="card mt-4">
        <div class="card-header pb-0 p-3">
            <div class="row">
                <div class="col-6 d-flex align-items-center">
                    <h6 class="mb-0">Ticket All</h6>
                </div>
                <div class="col-6 text-end">
                    <?php //if (!empty($canned_replies)): 
                    ?>
                    <!-- Display a single "Add New Card" button -->
                    <a href="<?= base_url('tickets/create_tickets') ?>"><button class="btn bg-gradient-dark mb-0 open-modal3"><i class="material-icons text-sm">add</i>&nbsp;&nbsp;Create Ticket</button></a>
                    <?php //endif; 
                    ?>
                </div>

            </div>
        </div>
        <div class=" p-3">
            <div class="table-responsive p-0">



                <!-- Main Container -->
                <div class="container">
                    <table class="table align-items-center mb-0">
                        <thead class="table-light">
                            <tr>

                                <th>Subject & Requestor</th>
                                <th>Assigned to</th>
                                <th>Reply Status</th>
                                <th>Status</th>
                                <th>Priority</th>
                                <th>Updated</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($ticket_all as $ticket): ?>
                                <tr>


                                    <td>
                                        <p class="text-xs font-weight-bold mb-0"><?= substr($ticket['subject'], 0, 2) ?>...<button class="btn btn-sms btn-success open-modal1" data-id="<?= $ticket['id'] ?>">Read More</button></p>
                                        <p class="text-xs text-secondary mb-0"><span class="text-muted"><?= $ticket['requestor']; ?></span></p>
                                    </td>
                                    <!-- <td><? //= $ticket['assigned_to'] ?? 'N/A'; 
                                                ?></td> -->
                                    <!-- <td>
                                        <span data-bs-toggle="tooltip" data-bs-placement="top" title="<?= isset($ticket['assigned_to']) ? $ticket['assigned_to'] . ' (' . ($ticket['department'] ?? 'N/A') . ')' : 'N/A'; ?>">
                                            <?= isset($ticket['assigned_to']) ? $ticket['assigned_to'] : 'N/A'; ?>
                                        </span>
                                    </td> -->

                                    <td>

                                        <span class="badge bg-dark text-white" data-bs-toggle="tooltip" data-bs-html="true" data-bs-placement="top" title="<strong><?= isset($ticket['assigned_to']) ? $ticket['assigned_to'] : 'N/A'; ?></strong><br><?= isset($ticket['department']) ? $ticket['department'] : 'N/A'; ?>">
                                            <img src=" <?= base_url('assets/img/shapes/default.png') ?>" alt="Profile Image" class="rounded-circle" style="width: 20px; height: 20px;"> </span>
                                    </td>

                                    <!-- <td><span class="badge bg-danger"><? //= ucfirst($ticket['sub_status']); 
                                                                            ?></span></td> -->
                                    <td>
                                        <!-- Dynamically display badge based on sub_status -->
                                        <?php if ($ticket['sub_status'] == 1): ?>
                                            <span class="badge bg-danger sm">Unanswered</span>
                                        <?php elseif ($ticket['sub_status'] == 2): ?>
                                            <span class="badge bg-info">Replied</span>
                                        <?php elseif ($ticket['sub_status'] == 3): ?>
                                            <span class="badge bg-success">Solved</span>
                                        <?php elseif ($ticket['sub_status'] == 4): ?>
                                            <span class="badge bg-primary">Awaiting User Reply</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">answered</span>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <!-- Dynamically display badge based on status -->
                                        <?php if ($ticket['status'] == 1): ?>
                                            <span class="badge bg-primary">Opened</span>
                                        <?php elseif ($ticket['status'] == 2): ?>
                                            <span class="badge bg-secondary">Closed</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning text-dark">Unknown Status</span>
                                        <?php endif; ?>
                                    </td>

                                    <!-- <td><span class="badge bg-warning text-dark"><? //= ucfirst($ticket['priority']); 
                                                                                        ?></span></td> -->
                                    <td>
                                        <!-- Dynamically display badge based on priority -->
                                        <?php if ($ticket['priority'] == 'medium'): ?>
                                            <span class="badge bg-warning text-dark">Medium</span>
                                        <?php elseif ($ticket['priority'] == 'low'): ?>
                                            <span class="badge bg-primary">Low</span>
                                        <?php elseif ($ticket['priority'] == 'high'): ?>
                                            <span class="badge bg-danger">High</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Unknown</span>
                                        <?php endif; ?>
                                    </td>

                                    <td><?= $ticket['updated_at'] ?? 'Never Updated'; ?></td>
                                    <td><?= date('d/m/Y H:i:s', $ticket['created_at']) ?></td>
                                    <td>


                                        <a href="<?= base_url('ticket_replies/get/' . $ticket['id']) ?>" class="btn  btn-primary"><i class="fas fa-eye"></i></a>
                                        <a href="<?= base_url('ticket_replies/delete/' . $ticket['id']) ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this?')"><i class="fas fa-trash tool-c"></i></a>

                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal Structure -->
<div id="materialModal" class="modal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Ticket </h5>
                <button type="button" class="close-modal" aria-label="Close">&times;</button>
            </div>
            <div class="modal-body">
                <p id="modal-message">Loading...</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger close-modal"><i class="fas fa-close">X</i></button>
            </div>
        </div>
    </div>
</div>



<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Open modal when trigger button is clicked
        document.querySelectorAll('.open-modal1').forEach(button => {
            button.addEventListener('click', function() {
                var replyId = this.getAttribute('data-id');
                var originalText = this.textContent;

                // Show loading state on button
                this.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...';
                this.disabled = true;

                // Fetch the content dynamically using AJAX (fetch API)
                fetch('<?= base_url('ticket_replies/get/') ?>' + replyId)
                    .then(response => response.json())
                    .then(data => {
                        // Set modal content
                        document.getElementById('modal-message').textContent = data.message;

                        // Remove loading state
                        button.textContent = originalText;
                        button.disabled = false;

                        // Show modal
                        document.getElementById('materialModal').style.display = 'block';
                    })
                    .catch(error => {
                        document.getElementById('modal-message').textContent = 'Error loading message';

                        // Remove loading state
                        button.textContent = originalText;
                        button.disabled = false;
                    });
            });
        });

        // Close modal when close button is clicked
        document.querySelectorAll('.close-modal').forEach(button => {
            button.addEventListener('click', function() {
                document.getElementById('materialModal').style.display = 'none';
            });
        });
    });
</script>
<?= $this->endsection() ?>