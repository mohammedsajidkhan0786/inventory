<?= $this->extend("admin/backend/layout/pages-layout"); ?>


<?= $this->section("content") ?>
<style>
    .spinner-border {
        display: none;
        border-radius: 50%;
        /* Ensure the loader is round */
    }
</style>
<div class="container mx-auto">
    <div class="row">
        <div class="col-lg-4 col-md-8 col-12 mx-auto">
            <div class="card z-index-0  mt-8">

                <div class="card-body">
                    <div class="login-form ">
                        <?php if (!session()->get('isLoggedIn')): ?>
                            <!-- Show the login form if the user is not logged in -->
                            <div id="alertMessage" style="display:none;" class="alert"></div>

                            <form id="loginForm" action="<?= site_url('auth/login') ?>" method="post" novalidate>
                                <?= csrf_field() ?>
                                <div class="form-group mb-3 my-3">
                                    <input type="text" name="email" id="email" class="form-control border" placeholder="Username or Email Address" required>
                                    <div class="invalid-feedback" id="emailError"></div>
                                </div>
                                <div class="form-group mb-3 mb-3">
                                    <input type="password" name="password" id="password" class="form-control border" placeholder="Password" required>
                                    <div class="invalid-feedback" id="passwordError"></div>
                                </div>
                                <!-- <div class="form-check form-switch d-flex align-items-center mb-3">
                    <input class="form-check-input" type="checkbox" id="rememberMe" checked>
                    <label class="form-check-label mb-0 ms-3" for="rememberMe">Remember me</label>
                </div> -->
                                <div class="text-center">
                                    <button type="submit" id="loginBtn" class="btn bg-gradient-primary w-100 my-4 mb-2">
                                        <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                        <span class="btn-text">Login</span>
                                    </button>
                                </div>
                                <p class="mt-4 text-sm text-center">
                                    Don't have an account?
                                    <a href="../pages/sign-up.html" class="text-primary text-gradient font-weight-bold">Sign up</a>
                                </p>
                            </form>
                        <?php else: ?>
                            <!-- If the user is logged in, show role-based content -->
                            <div class="alert alert-success text-center">
                                You are already logged in as <?= session()->get('username') ?> (<?= session()->get('role_name') ?>).
                            </div>
                            <div class="text-center">
                                <?php if (session()->get('role') == 'super_admin'): ?>
                                    <a href="<?= base_url('dashboard') ?>" class="btn bg-gradient-primary w-100 my-4 mb-2">Go to Admin Dashboard</a>
                                <?php elseif (session()->get('role') == 'agent'): ?>
                                    <a href="<?= base_url('dashboard') ?>" class="btn bg-gradient-primary w-100 my-4 mb-2">Go to Agent Dashboard</a>
                                <?php elseif (session()->get('role') == 'user'): ?>
                                    <a href="<?= base_url('dashboard') ?>" class="btn bg-gradient-primary w-100 my-4 mb-2">Go to User Dashboard</a>
                                <?php endif; ?>
                                <a href="<?= base_url('auth/logout') ?>" class="btn bg-gradient-dark w-100 my-4 mb-2">Logout</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $('#loginForm').on('submit', function(e) {
            e.preventDefault(); // Prevent default form submission

            // Clear previous errors
            $('.form-control').removeClass('is-invalid');
            $('#alertMessage').hide();

            // Show the loader and disable the button
            $('#loginBtn').prop('disabled', true);
            $('#loginBtn .spinner-border').show();
            //$('#loginBtn .btn-text').text('Logging in...');

            // Set a minimum timer for the loading (e.g., 2 seconds)
            var minDuration = 2000; // Minimum loading time in milliseconds (2 seconds)
            var requestFinished = false;
            var timerFinished = false;

            setTimeout(function() {
                timerFinished = true;
                if (requestFinished) {
                    hideLoader();
                }
            }, minDuration);

            // Get form data
            var formData = $(this).serialize();

            // Send AJAX request
            $.ajax({
                url: '<?= site_url('auth/login') ?>',
                method: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    requestFinished = true;

                    if (response.status === 'success') {
                        // Redirect on success
                        window.location.href = response.redirect;
                    } else if (response.status === 'error') {
                        // Display validation errors or error messages
                        if (response.errors) {
                            if (response.errors.email) {
                                $('#email').addClass('is-invalid');
                                $('#emailError').text(response.errors.email);
                            }
                            if (response.errors.password) {
                                $('#password').addClass('is-invalid');
                                $('#passwordError').text(response.errors.password);
                            }
                        } else {
                            // Display general error message
                            $('#alertMessage').text(response.message).addClass('alert-danger').show();
                        }
                    }

                    // Check if both timer and request are finished before hiding loader
                    if (timerFinished) {
                        hideLoader();
                    }
                },
                error: function(xhr, status, error) {
                    requestFinished = true;

                    // Handle any AJAX error
                    $('#alertMessage').text('Something went wrong. Please try again.').addClass('alert-danger').show();

                    // Check if both timer and request are finished before hiding loader
                    if (timerFinished) {
                        hideLoader();
                    }
                }
            });

            function hideLoader() {
                // Hide the loader and re-enable the button
                $('#loginBtn').prop('disabled', false);
                $('#loginBtn .spinner-border').hide();
                $('#loginBtn .btn-text').text('Login');
            }
        });
    });
</script>
<?= $this->endsection() ?>