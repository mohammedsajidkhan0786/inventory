<nav class="navbar navbar-expand-lg blur border-radius-xl top-0 z-index-3 shadow position-absolute my-3 py-2 start-0 end-0 mx-4">
    <div class="container-fluid ps-2 pe-0">
        <a class="navbar-brand font-weight-bolder ms-lg-0 ms-3 " href="../pages/dashboard.html">
            Tamex
        </a>
        <button class="navbar-toggler shadow-none ms-2" type="button" data-bs-toggle="collapse" data-bs-target="#navigation" aria-controls="navigation" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon mt-2">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
            </span>
        </button>
        <div class="collapse navbar-collapse" id="navigation">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item">
                    <a class="nav-link d-flex align-items-center me-2 active" aria-current="page" href="<?= base_url('home') ?>">
                        <i class="fa fa-chart-pie opacity-6 text-dark me-1"></i>
                        Home
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link me-2" href="<?= base_url('create_ticket') ?>">
                        <i class="fa fa-user opacity-6 text-dark me-1"></i>
                        Submit Ticket
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link me-2" href="../pages/sign-up.html">
                        <i class="fas fa-user-circle opacity-6 text-dark me-1"></i>
                        Faq
                    </a>
                </li>
                <!-- <li class="nav-item">
                    <a class="nav-link me-2" href="<?= site_url('language/switch/en') ?>">
                        <i class="fas fa-user-circle opacity-6 text-dark me-1 <?= session()->get('language') == 'en' ? 'selected' : '' ?>"></i>
                        english
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link me-2" href="<?= site_url('language/switch/ar') ?>">
                        <i class="fas fa-user-circle opacity-6 text-dark me-1 <?= session()->get('language') == 'ar' ? 'selected' : '' ?>"></i>
                        Arabic
                    </a>
                </li> -->


            </ul>

            <ul class="navbar-nav d-lg-flex d-none">
                <?php if (session()->get('isLoggedIn')): ?>
                    <!-- Display different options based on the user's role -->
                    <?php if (session()->get('role') == 'super_admin'): ?>
                        <li class="nav-item">
                            <a href="<?= base_url('dashboard') ?>" class="btn btn-sm mb-0 me-1 bg-gradient-dark">Admin Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a href="<?= base_url('auth/logout') ?>" class="btn btn-sm mb-0 me-1 bg-gradient-dark">Logout</a>
                        </li>
                    <?php elseif (session()->get('role') == 'agent'): ?>
                        <li class="nav-item">
                            <a href="<?= base_url('dashboard') ?>" class="btn btn-sm mb-0 me-1 bg-gradient-dark">Agent Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a href="<?= base_url('auth/logout') ?>" class="btn btn-sm mb-0 me-1 bg-gradient-dark">Logout</a>
                        </li>
                    <?php elseif (session()->get('role') == 'user'): ?>
                        <li class="nav-item">
                            <a href="<?= base_url('dashboard') ?>" class="btn btn-sm mb-0 me-1 bg-gradient-dark">User Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a href="<?= base_url('auth/logout') ?>" class="btn btn-sm mb-0 me-1 bg-gradient-dark">Logout</a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <!-- If the user is not logged in, show the login link -->
                    <li class="nav-item">
                        <a href="<?= base_url('auth/login') ?>" class="btn btn-sm mb-0 me-1 bg-gradient-dark">Login</a>
                    </li>
                <?php endif; ?>
            </ul>


        </div>
    </div>
</nav>

<!-- <script>
    document.querySelectorAll('.switch').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const direction = this.getAttribute('href').includes('rtl') ? 'rtl' : 'ltr';

            // Change the direction of the HTML tag
            document.documentElement.setAttribute('dir', direction);

            // Change the CSS file
            const styleLink = document.getElementById('pagestyle');
            styleLink.href = styleLink.href.replace(/(rtl)?\.css/, (direction === 'rtl' ? '-rtl' : '') + '.css');

            // Optionally: send a request to update session direction on the server
            fetch(this.getAttribute('href'));
        });
    });
</script> -->