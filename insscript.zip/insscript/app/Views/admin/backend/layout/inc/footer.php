<footer class=" bg-white shadow footer position-absolute bottom-0  w-100">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="border-only-sm-bottom">
                    <p class="py-4  mb-0">
                        Copyright © 2024 All Rights Reserved. </p>
                </div>
                <!-- /.border-only-sm-bottom -->
            </div>
            <!-- /col -->
            <div class="col-lg-6">
                <div class="pt-4 menu float-lg-end">


                    <span class="d-block d-sm-inline-block mb-2 mb-sm-0">
                        <a href="http://localhost/script/privacy-policy"><?= lang('Home.privacy.heading') ?></a>
                    </span>
                    <span class="d-block d-sm-inline-block mb-2 mb-sm-0">
                        <a href="http://localhost/script/terms">Terms of Use</a>
                    </span>


                    <div class="dropdown">
                        <button class=" mb-3  bg-gradient-dark dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            Language
                        </button>
                        <ul class="dropdown-menu dropdown-content">
                            <li><a class="dropdown-item <?= session()->get('language') == 'en' ? 'selected' : '' ?>" href="<?= site_url('language/switch/en') ?>">English</a></li>
                            <li><a class="dropdown-item <?= session()->get('language') == 'ar' ? 'selected' : '' ?>" href="<?= site_url('language/switch/ar') ?>">Arabic</a></li>
                        </ul>
                    </div>
                    <!-- /.dropdown -->
                </div>
                <!-- /.menu -->
            </div>
            <!-- /col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container -->
</footer>