<?= $this->extend('layouts/default') ?>
<?= $this->section('content') ?>

<div class="container mt-5">
    <h3>Step 4: Finalization</h3>
    <p>The installation is complete! You can now log in to your application.</p>
    <a href="<?= base_url('auth/login') ?>" class="btn btn-primary">Go to Dashboard</a>
</div>

<?= $this->endSection() ?>