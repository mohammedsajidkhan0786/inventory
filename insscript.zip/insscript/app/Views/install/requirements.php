<?= $this->extend('layouts/default') ?>
<?= $this->section('content') ?>

<div class="container mt-5">
    <div class="row">
        <div class="col-3">
            <!-- Sidebar for steps -->
            <!-- <ul class="list-group">
                <li class="list-group-item active"><i class="fas fa-cogs"></i> Requirements</li>
                <li class="list-group-item"><i class="fas fa-key"></i> Permissions</li>
                <li class="list-group-item"><i class="fas fa-hdd"></i> Install</li>
                <li class="list-group-item"><i class="fas fa-check-circle"></i> Finishing</li>
            </ul> -->
        </div>
        <div class="col-9">
            <h3>System Requirements</h3>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($requirements as $requirement): ?>
                        <tr>
                            <td><?= esc($requirement['label']) ?></td>
                            <td><?= esc($requirement['description']) ?></td>
                            <td>
                                <?php if ($requirement['status'] == 'passed'): ?>
                                    <span class="text-success"><i class="fa fa-check-circle"></i> Passed</span>
                                <?php else: ?>
                                    <span class="text-danger"><i class="fa fa-times-circle"></i> Failed</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div class="d-flex justify-content-end">
                <a href="<?= base_url('/install/step1') ?>" class="btn btn-primary">Next</a>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>