<?= $this->extend('layouts/default') ?>
<?= $this->section('content') ?>

<div class="container mt-5">
    <h3>Step 3: Create Database Tables</h3>
    <p>Setting up the database structure...</p>

    <?php
    // Connect to the database and set up the forge for table creation
    $db = \Config\Database::connect();
    $forge = \Config\Database::forge();

    // Example: Create 'users' table if it doesn't exist
    if (!$db->tableExists('users')) {
        $fields = [
            'id' => ['type' => 'INT', 'auto_increment' => true],
            'username' => ['type' => 'VARCHAR', 'constraint' => '100'],
            'password' => ['type' => 'VARCHAR', 'constraint' => '100'],
            'created_at' => ['type' => 'DATETIME', 'null' => true]
        ];
        $forge->addField($fields);
        $forge->addKey('id', true);
        $forge->createTable('users');

        echo '<div class="alert alert-success">The users table has been created successfully.</div>';
    } else {
        echo '<div class="alert alert-info">The users table already exists.</div>';
    }

    // Create the 'posts' table if it doesn't exist
    if (!$db->tableExists('posts')) {
        $fields = [
            'id' => ['type' => 'INT', 'auto_increment' => true],
            'title' => ['type' => 'VARCHAR', 'constraint' => '255'],
            'content' => ['type' => 'TEXT'],
            'user_id' => ['type' => 'INT'],
            'created_at' => ['type' => 'DATETIME', 'null' => true]
        ];
        $forge->addField($fields);
        $forge->addKey('id', true);
        $forge->createTable('posts');

        echo '<div class="alert alert-success">The posts table has been created successfully.</div>';
    } else {
        echo '<div class="alert alert-info">The posts table already exists.</div>';
    }
    ?>

    <a href="<?= base_url('install/finalize') ?>" class="btn btn-primary mt-3">Finalize Installation</a>
</div>

<?= $this->endSection() ?>