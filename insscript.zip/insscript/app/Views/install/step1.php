<?= $this->extend('layouts/default') ?>
<?= $this->section('content') ?>

<div class="container mt-5">
    <h3>Step 1: Database Configuration</h3>

    <!-- Display general error message if available -->
    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger">
            <?= session()->getFlashdata('error') ?>
        </div>
    <?php endif; ?>

    <form action="<?= base_url('install/configureDatabase') ?>" method="post">
        <?= csrf_field() ?>

        <div class="form-group">
            <label for="db_host">Database Host</label>
            <input type="text" name="db_host" id="db_host" class="form-control <?= (session('errors.db_host')) ? 'is-invalid' : '' ?>" value="<?= old('db_host') ?>">
            <?php if (session('errors.db_host')): ?>
                <div class="invalid-feedback">
                    <?= session('errors.db_host') ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for="db_user">Database User</label>
            <input type="text" name="db_user" id="db_user" class="form-control <?= (session('errors.db_user')) ? 'is-invalid' : '' ?>" value="<?= old('db_user') ?>">
            <?php if (session('errors.db_user')): ?>
                <div class="invalid-feedback">
                    <?= session('errors.db_user') ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for="db_pass">Database Password</label>
            <input type="password" name="db_pass" id="db_pass" class="form-control <?= (session('errors.db_pass')) ? 'is-invalid' : '' ?>">
            <?php if (session('errors.db_pass')): ?>
                <div class="invalid-feedback">
                    <?= session('errors.db_pass') ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for="db_name">Database Name</label>
            <input type="text" name="db_name" id="db_name" class="form-control <?= (session('errors.db_name')) ? 'is-invalid' : '' ?>" value="<?= old('db_name') ?>">
            <?php if (session('errors.db_name')): ?>
                <div class="invalid-feedback">
                    <?= session('errors.db_name') ?>
                </div>
            <?php endif; ?>
        </div>

        <button type="submit" class="btn btn-primary mt-3">Next</button>
    </form>
</div>

<?= $this->endSection() ?>