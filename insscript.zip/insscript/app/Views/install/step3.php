<?= $this->extend('layouts/default') ?>
<?= $this->section('content') ?>

<div class="container mt-5">
    <h3>Step 3: Create Database Tables</h3>
    <p>Setting up the database structure...</p>

    <?php if (isset($success) && $success): ?>
        <div class="alert alert-success"><?= esc($message) ?></div>
    <?php else: ?>
        <div class="alert alert-danger"><?= esc($message) ?></div>
    <?php endif; ?>

    <a href="<?= base_url('install/finalize') ?>" class="btn btn-primary mt-3">Finalize Installation</a>
</div>

<?= $this->endSection() ?>