<?= $this->extend('layouts/default') ?>
<?= $this->section('content') ?>

<div class="container mt-5">
    <h3>Step 2: File Permissions</h3>
    <p>Checking if necessary directories are writable...</p>

    <table class="table">
        <thead>
            <tr>
                <th>Directory</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>./writable/logs/</td>
                <td><span class="text-success"><i class="fas fa-check-circle"></i> Writable</span></td>
            </tr>
            <!-- Add more directory checks if needed -->
        </tbody>
    </table>

    <a href="<?= base_url('/install/step3') ?>" class="btn btn-primary">Next</a>
</div>

<?= $this->endSection() ?>