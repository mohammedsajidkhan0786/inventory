<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $this->renderSection('title') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        ul.list-group a {
            text-decoration: none;
            /* Removes the underline */
        }

        ul.list-group a:hover {
            text-decoration: none;
            /* Ensures underline doesn't appear on hover */
        }

        .disabled-link {
            pointer-events: none;
            color: #aaa;
            /* Makes the disabled link look gray */
            text-decoration: none;
            /* Removes the underline from disabled links */
        }

        .active {
            font-weight: bold;
            color: #007bff;
            /* Highlight active step */
        }

        ul.list-group a {
            text-decoration: none;
            /* Removes the underline */
        }

        ul.list-group a:hover {
            text-decoration: none;
            /* Ensures underline doesn't appear on hover */
        }

        .disabled-link {
            pointer-events: none;
            color: #aaa;
            /* Makes the disabled link look gray */
            text-decoration: none;
            /* Removes the underline from disabled links */
        }

        .active {
            font-weight: bold;
            color: #007bff;
            /* Highlight active step */
        }
    </style>

</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Left Sidebar -->
            <div class="col-md-3 ">
                <h4>Installation Steps</h4>


                <ul class="list-group">
                    <!-- Step 1: Requirements -->
                    <li class="list-group-item <?= (uri_string() == 'install/step1') ? 'active' : '' ?>">
                        <a href="<?= base_url('/install/step1') ?>"
                            class="<?= (uri_string() != 'install/step1') ? 'disabled-link' : '' ?>">
                            <i class="fas fa-cogs"></i> Requirements
                        </a>
                    </li>

                    <!-- Step 2: Permissions -->
                    <li class="list-group-item <?= (uri_string() == 'install/step2') ? 'active' : '' ?>">
                        <a href="<?= base_url('/install/step2') ?>"
                            class="<?= (uri_string() == 'install/step1') ? '' : 'disabled-link' ?>">
                            <i class="fas fa-key"></i> Permissions
                        </a>
                    </li>

                    <!-- Step 3: Install -->
                    <li class="list-group-item <?= (uri_string() == 'install/step3') ? 'active' : '' ?>">
                        <a href="<?= base_url('/install/step3') ?>"
                            class="<?= (uri_string() == 'install/step2') ? '' : 'disabled-link' ?>">
                            <i class="fas fa-hdd"></i> Install
                        </a>
                    </li>

                    <!-- Step 4: Finishing -->
                    <li class="list-group-item <?= (uri_string() == 'install/finalize') ? 'active' : '' ?>">
                        <a href="<?= base_url('/install/finalize') ?>"
                            class="<?= (uri_string() == 'install/step3') ? '' : 'disabled-link' ?>">
                            <i class="fas fa-check-circle"></i> Finishing
                        </a>
                    </li>
                </ul>





            </div>

            <!-- Right Content Area -->
            <div class="col-md-8">
                <?= $this->renderSection('content') ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>