<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .login-container {
            margin-top: 80px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-form {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
        }

        .login-form input {
            margin-bottom: 15px;
        }

        .login-form .alert {
            margin-bottom: 20px;
        }

        .spinner-border {
            display: none;
            border-radius: 50%;
            /* Ensure the loader is round */
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="row login-container">
            <div class="col-md-4">
                <div class="login-form">

                    <!-- Placeholder for error messages -->
                    <div id="alertMessage" style="display:none;" class="alert"></div>

                    <!-- Login Form -->
                    <form id="loginForm" action="<?= site_url('auth/login') ?>" method="post" novalidate>
                        <?= csrf_field() ?>

                        <!-- Email or Username Field -->
                        <div class="form-group mb-3">
                            <input type="text" name="email" id="email" class="form-control" placeholder="Username or Email Address" required>
                            <div class="invalid-feedback" id="emailError"></div>
                        </div>

                        <!-- Password Field -->
                        <div class="form-group mb-3">
                            <input type="password" name="password" id="password" class="form-control" placeholder="Password" required>
                            <div class="invalid-feedback" id="passwordError"></div>
                        </div>

                        <!-- Remember Me Checkbox -->
                        <div class="form-group form-check">
                            <input type="checkbox" name="remember" class="form-check-input" id="rememberMe">
                            <label class="form-check-label" for="rememberMe">Remember Me</label>
                            <a href="#" class="float-end">Forgot Password?</a>
                        </div>

                        <!-- Login Button with Loader -->
                        <button type="submit" id="loginBtn" class="btn btn-success w-100">
                            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                            <span class="btn-text">Login</span>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#loginForm').on('submit', function(e) {
                e.preventDefault(); // Prevent default form submission

                // Clear previous errors
                $('.form-control').removeClass('is-invalid');
                $('#alertMessage').hide();

                // Show the loader and disable the button
                $('#loginBtn').prop('disabled', true);
                $('#loginBtn .spinner-border').show();
                //$('#loginBtn .btn-text').text('Logging in...');

                // Set a minimum timer for the loading (e.g., 2 seconds)
                var minDuration = 2000; // Minimum loading time in milliseconds (2 seconds)
                var requestFinished = false;
                var timerFinished = false;

                setTimeout(function() {
                    timerFinished = true;
                    if (requestFinished) {
                        hideLoader();
                    }
                }, minDuration);

                // Get form data
                var formData = $(this).serialize();

                // Send AJAX request
                $.ajax({
                    url: '<?= site_url('auth/login') ?>',
                    method: 'POST',
                    data: formData,
                    dataType: 'json',
                    success: function(response) {
                        requestFinished = true;

                        if (response.status === 'success') {
                            // Redirect on success
                            window.location.href = response.redirect;
                        } else if (response.status === 'error') {
                            // Display validation errors or error messages
                            if (response.errors) {
                                if (response.errors.email) {
                                    $('#email').addClass('is-invalid');
                                    $('#emailError').text(response.errors.email);
                                }
                                if (response.errors.password) {
                                    $('#password').addClass('is-invalid');
                                    $('#passwordError').text(response.errors.password);
                                }
                            } else {
                                // Display general error message
                                $('#alertMessage').text(response.message).addClass('alert-danger').show();
                            }
                        }

                        // Check if both timer and request are finished before hiding loader
                        if (timerFinished) {
                            hideLoader();
                        }
                    },
                    error: function(xhr, status, error) {
                        requestFinished = true;

                        // Handle any AJAX error
                        $('#alertMessage').text('Something went wrong. Please try again.').addClass('alert-danger').show();

                        // Check if both timer and request are finished before hiding loader
                        if (timerFinished) {
                            hideLoader();
                        }
                    }
                });

                function hideLoader() {
                    // Hide the loader and re-enable the button
                    $('#loginBtn').prop('disabled', false);
                    $('#loginBtn .spinner-border').hide();
                    $('#loginBtn .btn-text').text('Login');
                }
            });
        });
    </script>

</body>

</html>