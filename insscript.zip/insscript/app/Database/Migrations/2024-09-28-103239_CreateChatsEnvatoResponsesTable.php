<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateChatsEnvatoResponsesTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 10,
                'unsigned'       => true,
                'auto_increment' => true
            ],
            'ticket_id' => [
                'type'       => 'INT',
                'constraint' => 10,
                'unsigned'   => true,
                'null'       => false,
            ],
            'response' => [
                'type' => 'TEXT',
                'null' => false,
            ],
            'responded_at' => [
                'type'       => 'INT',
                'constraint' => 10,
                'unsigned'   => true,
                'null'       => false,
            ],
        ]);

        $this->forge->addKey('id', true);  // Primary key
        $this->forge->createTable('chats_envato_responses');
    }

    public function down()
    {
        $this->forge->dropTable('chats_envato_responses');
    }
}
