<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateTicketsRepliesQuotesTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 10,
                'unsigned'       => true,
                'auto_increment' => true
            ],
            'ticket_reply_id' => [
                'type'       => 'INT',
                'constraint' => 10,
                'unsigned'   => true,
                'null'       => false,
            ],
            'message' => [
                'type' => 'TEXT',
                'null' => false,
            ],
        ]);

        $this->forge->addKey('id', true);  // Primary key
        $this->forge->createTable('tickets_replies_quotes');
    }

    public function down()
    {
        $this->forge->dropTable('tickets_replies_quotes');
    }
}
