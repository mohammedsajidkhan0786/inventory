<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $allowedFields = [
        'first_name',
        'last_name',
        'username',
        'email_address',
        'password',
        'role',
        'is_online',
        'last_activity',
        'registered_at',
        'is_verified'
    ];
    protected $beforeInsert = ['hashPassword'];

    protected function hashPassword(array $data)
    {
        if (isset($data['data']['password'])) {
            $data['data']['password'] = password_hash($data['data']['password'], PASSWORD_DEFAULT);
        }
        return $data;
    }

    public function getUserByEmailOrUsername($emailOrUsername)
    {
        return $this->select('users.*, roles.name as role_name, roles.access_key as role_key')
            ->join('roles', 'roles.id = users.role')
            ->where('email_address', $emailOrUsername)
            ->orWhere('username', $emailOrUsername)
            ->first();
    }

    // public function getRecentlyRegisteredUsers($limit = 5)
    // {
    //     return $this->orderBy('registered_at', 'DESC')
    //         ->limit($limit)
    //         ->findAll();
    // }

    // public function getRecentlyRegisteredUsers($limit = 5)
    // {
    //     $users = $this->orderBy('registered_at', 'DESC')
    //         ->limit($limit)
    //         ->findAll();

    //     // Check online status
    //     foreach ($users as &$user) {
    //         // Consider user online if active within the last 5 minutes
    //         $user['is_online'] = (strtotime($user['last_activity']) > strtotime('-5 minutes')) ? true : false;
    //     }

    //     return $users;
    // }

    // public function getRecentlyRegisteredUsers($limit = 5)
    // {
    //     // Join the roles table to get the role name instead of the role_id
    //     $users = $this->select('users.*, roles.name')
    //         ->join('roles', 'users.role = roles.id')
    //         ->orderBy('users.registered_at', 'DESC')
    //         ->limit($limit)
    //         ->findAll();

    //     // Check online status
    //     foreach ($users as &$user) {
    //         // Consider user online if active within the last 5 minutes
    //         $user['is_online'] = (strtotime($user['last_activity']) > strtotime('-5 minutes')) ? true : false;
    //     }

    //     return $users;
    // }

    // public function getRecentlyRegisteredUsers($limit = 5)
    // {
    //     // Join the roles table to get the role name instead of the role_id
    //     $users = $this->select('users.*, roles.name')
    //         ->join('roles', 'users.role = roles.id')
    //         ->orderBy('users.registered_at', 'DESC')
    //         ->limit($limit)
    //         ->findAll();

    //     // Check online status
    //     foreach ($users as &$user) {
    //         // Consider user online if active within the last 5 minutes
    //         $user['is_online'] = (time() - strtotime($user['last_activity'])) < 300;  // 300 seconds = 5 minutes
    //     }

    //     return $users;
    // }

    // public function getRecentlyRegisteredUsers($limit = 5)
    // {
    //     // Join the roles table to get the role name instead of the role_id
    //     $users = $this->select('users.*, roles.name AS role_name')  // Select role_name from roles
    //         ->join('roles', 'users.role = roles.id')  // Join with roles table
    //         ->orderBy('users.registered_at', 'DESC')
    //         ->limit($limit)
    //         ->findAll();

    //     // Check online status
    //     foreach ($users as &$user) {
    //         // Consider user online if active within the last 5 minutes
    //         if ($user['last_activity']) {
    //             $user['is_online'] = (time() - $user['last_activity']) < 300;
    //             log_message('info', 'User {username} is {status}.', [
    //                 'username' => $user['username'],
    //                 'status' => $user['is_online'] ? 'online' : 'offline'
    //             ]);
    //         } else {
    //             $user['is_online'] = false;
    //             log_message('error', 'User {username} has no last_activity set.', ['username' => $user['username']]);
    //         }
    //     }

    //     return $users;
    // }

    // public function getRecentlyRegisteredUsers($limit = 5)
    // {
    //     // Join the roles table to get the role name instead of the role_id
    //     $users = $this->select('users.*, roles.name AS role_name')
    //         ->join('roles', 'users.role = roles.id')
    //         ->orderBy('users.registered_at', 'DESC')
    //         ->limit($limit)
    //         ->findAll();

    //     // Check online status
    //     foreach ($users as &$user) {
    //         // Ensure last_activity is a valid Unix timestamp before checking
    //         if (isset($user['last_activity']) && $user['last_activity'] > 0) {
    //             // Consider user online if active within the last 5 minutes (300 seconds)
    //             $user['is_online'] = (time() - $user['last_activity']) < 30;
    //         } else {
    //             $user['is_online'] = false;
    //         }
    //     }

    //     return $users;
    // }

    // public function getRecentlyRegisteredUsers($limit = 5)
    // {
    //     // Join the roles table to get the role name instead of the role_id
    //     $users = $this->select('users.*, roles.name AS role_name')
    //         ->join('roles', 'users.role = roles.id')
    //         ->orderBy('users.registered_at', 'DESC')
    //         ->limit($limit)
    //         ->findAll();

    //     // Check online status
    //     foreach ($users as &$user) {
    //         // Ensure last_activity is a valid Unix timestamp before checking
    //         if (isset($user['last_activity']) && $user['last_activity'] > 0) {
    //             // Consider user online if active within the last 5 minutes (300 seconds)
    //             $user['is_online'] = (time() - $user['last_activity']) < 30;  // 300 seconds = 5 minutes
    //         } else {
    //             $user['is_online'] = false;
    //         }
    //     }

    //     return $users;
    // }

    public function getRecentlyRegisteredUsers()
    {
        // Join the roles table to get the role name instead of the role_id
        $users = $this->select('users.*, roles.name AS role_name')
            ->join('roles', 'users.role = roles.id')
            ->orderBy('users.registered_at', 'ASC')
            //->limit($limit)
            ->findAll();

        // Check online status
        foreach ($users as &$user) {
            // Ensure last_activity is a valid Unix timestamp before checking
            if (isset($user['last_activity']) && $user['last_activity'] > 0) {
                // Consider user online if active within the last 5 minutes (300 seconds)
                $user['is_online'] = (time() - $user['last_activity']) < 300;
            } else {
                $user['is_online'] = false;
            }
        }

        return $users;
    }
}
