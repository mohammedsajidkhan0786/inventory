<?php

namespace App\Models;

use CodeIgniter\Model;

class TicketModel extends Model
{

    protected $table = 'tickets'; // Your ticket table name
    protected $primaryKey = 'id';
    //protected $allowedFields = ['subject', 'requestor', 'assigned_to', 'status', 'status', 'priority', 'updated_at', 'created_at'];
    protected $allowedFields = ['subject', 'requestor', 'user_id', 'assigned_to', 'reply_status', 'status', 'priority', 'updated_at', 'created_at'];
    // Method to get the total number of open tickets
    public function getTotalOpenTickets()
    {
        //return $this->where('status', 'open')->countAllResults();
        return $this->countAllResults();
    }

    // Method to get the total number of closed tickets
    public function getTotalClosedTickets()
    {
        return $this->where('status', 'closed')->countAllResults();
    }

    // Method to get the total number of tickets
    public function getTotalTickets()
    {
        return $this->countAllResults();
    }

    // Method to get the total number of users (assuming you have a 'users' table)
    public function getTotalUsers()
    {
        $db = db_connect();
        $builder = $db->table('users');  // Assuming the 'users' table exists
        return $builder->countAllResults();
    }

    public function getMonthlyTicketStats()
    {
        // SQL query to group by month and count tickets for each month
        return $this->select("MONTH(created_at) as month, COUNT(id) as total")
            ->groupBy('MONTH(created_at)')
            ->orderBy('MONTH(created_at)', 'ASC')
            ->findAll();
    }

    // Fetch canned replies based on user role
    // public function getticketByRole($role)
    // {
    //     if ($role == 'super_admin') {
    //         // Super Admin can see all canned replies
    //         return $this->select('tickets.*, users.username as requestor')
    //             ->join('users', 'users.id = tickets.user_id')
    //             ->where('tickets.user_id', $role)
    //             ->findAll();
    //     } elseif ($role == 'agent') {
    //         // Agents see only their own canned replies
    //         return $this->where('created_by_role', 'agent')->findAll();
    //     } elseif ($role == 'user') {
    //         // Users see only their own canned replies
    //         return $this->where('created_by_role', 'user')->findAll();
    //     }

    //     return [];
    // }

    // public function getTicketByRole($role, $userId = null)
    // {
    //     if ($role == 'super_admin') {
    //         // Super Admin can see all tickets
    //         return $this->select('tickets.*, users.username as requestor')
    //             ->join('users', 'users.id = tickets.user_id')
    //             ->join('tickets_departments', 'tickets_departments.id = users.id', 'left') // Join with department
    //             ->findAll();
    //     } elseif ($role == 'agent') {
    //         // Agents see only the tickets they created
    //         return $this->select('tickets.*, users.username as requestor')
    //             ->join('users', 'users.id = tickets.user_id')
    //             ->where('tickets.created_by_role', 'agent')
    //             ->where('tickets.user_id', $userId) // Assuming agents have user ID related to them
    //             ->findAll();
    //     } elseif ($role == 'user') {
    //         // Users see only the tickets they created
    //         return $this->select('tickets.*, users.username as requestor')
    //             ->join('users', 'users.id = tickets.user_id')
    //             ->where('tickets.created_by_role', 'user')
    //             ->where('tickets.user_id', $userId) // Ensuring users see their own tickets
    //             ->findAll();
    //     }

    //     return [];
    // }
    // public function getTicketByRole($role, $userId = null)
    // {
    //     if ($role == 'super_admin') {
    //         // Super Admin can see all tickets
    //         return $this->select('tickets.*, users.username as requestor, tickets_departments.name as department')
    //             ->join('users', 'users.id = tickets.user_id')
    //             ->join('tickets_departments', 'tickets_departments.id = users.id', 'left') // Join with department
    //             ->findAll();
    //     } elseif ($role == 'agent') {
    //         // Agents see only the tickets they created
    //         return $this->select('tickets.*, users.username as requestor, departments.name as department')
    //             ->join('users', 'users.id = tickets.user_id')
    //             ->join('departments', 'departments.id = users.department_id', 'left') // Join with department
    //             ->where('tickets.created_by_role', 'agent')
    //             ->where('tickets.user_id', $userId) // Ensuring agents see their own tickets
    //             ->findAll();
    //     } elseif ($role == 'user') {
    //         // Users see only the tickets they created
    //         return $this->select('tickets.*, users.username as requestor, departments.name as department')
    //             ->join('users', 'users.id = tickets.user_id')
    //             ->join('departments', 'departments.id = users.department_id', 'left') // Join with department
    //             ->where('tickets.created_by_role', 'user')
    //             ->where('tickets.user_id', $userId) // Ensuring users see their own tickets
    //             ->findAll();
    //     }

    //     return [];
    // }
    public function getTicketByRole($role, $userId = null)
    {
        if ($role == 'super_admin') {
            // Super Admin can see all tickets
            return $this->select('tickets.*, requestor.username as requestor, assigned.username as assigned_to, tickets_departments.name as department')
                ->join('users as requestor', 'requestor.id = tickets.user_id')  // Join users as requestor
                ->join('users as assigned', 'assigned.id = tickets.assigned_to', 'left')  // Join users as assigned_to
                ->join('tickets_departments', 'tickets_departments.id = department_id', 'left')  // Join with tickets_departments
                ->findAll();
        } elseif ($role == 'agent') {
            // Agents see only the tickets they created
            return $this->select('tickets.*, requestor.username as requestor, assigned.username as assigned_to, tickets_departments.name as department')
                ->join('users as requestor', 'requestor.id = tickets.user_id')  // Join users as requestor
                ->join('users as assigned', 'assigned.id = tickets.assigned_to_id', 'left')  // Join users as assigned_to
                ->join('tickets_departments', 'tickets_departments.id = assigned.department_id', 'left')  // Join with tickets_departments
                ->where('tickets.created_by_role', 'agent')  // Filter by agent-created tickets
                ->where('tickets.user_id', $userId)  // Ensure the agent sees their own tickets
                ->findAll();
        } elseif ($role == 'user') {
            // Users see only the tickets they created
            return $this->select('tickets.*, requestor.username as requestor, assigned.username as assigned_to, tickets_departments.name as department')
                ->join('users as requestor', 'requestor.id = tickets.user_id')  // Join users as requestor
                ->join('users as assigned', 'assigned.id = tickets.assigned_to_id', 'left')  // Join users as assigned_to
                ->join('tickets_departments', 'tickets_departments.id = assigned.department_id', 'left')  // Join with tickets_departments
                ->where('tickets.created_by_role', 'user')  // Filter by user-created tickets
                ->where('tickets.user_id', $userId)  // Ensure the user sees their own tickets
                ->findAll();
        }

        return [];
    }


    public function getticketByOpened($role)
    {
        // if ($role == 'super_admin') {
        //     // Super Admin can see all tickets
        //     return $this->select('tickets.*, users.username as requestor')
        //         ->join('users', 'users.id = tickets.user_id')
        //         ->where('tickets.status = ', 1)
        //         // ->where('tickets.user_id', $userId)
        //         ->findAll();
        // }

        if ($role == 'super_admin') {
            // Super Admin can see all tickets
            return $this->select('tickets.*, requestor.username as requestor, assigned.username as assigned_to, tickets_departments.name as department')
                ->join('users as requestor', 'requestor.id = tickets.user_id')  // Join users as requestor
                ->join('users as assigned', 'assigned.id = tickets.assigned_to', 'left')  // Join users as assigned_to
                ->join('tickets_departments', 'tickets_departments.id = department_id', 'left')  // Join with tickets_departments
                ->where('tickets.status = ', 1)
                ->findAll();
        }
    }

    public function getticketByclose($role)
    {
        if ($role == 'super_admin') {
            // Super Admin can see all tickets
            return $this->select('tickets.*, requestor.username as requestor, assigned.username as assigned_to, tickets_departments.name as department')
                ->join('users as requestor', 'requestor.id = tickets.user_id')  // Join users as requestor
                ->join('users as assigned', 'assigned.id = tickets.assigned_to', 'left')  // Join users as assigned_to
                ->join('tickets_departments', 'tickets_departments.id = department_id', 'left')  // Join with tickets_departments
                ->where('tickets.status = ', 2)
                ->findAll();
        }
    }

    // public function getticketByassigned($role)
    // {
    //     if ($role == 'super_admin') {
    //         // Super Admin can see all tickets
    //         return $this->select('tickets.*, requestor.username as requestor, assigned.username as assigned_to, tickets_departments.name as department')
    //             ->join('users as requestor', 'requestor.id = tickets.user_id')  // Join users as requestor
    //             ->join('users as assigned', 'assigned.id = tickets.assigned_to', 'left')  // Join users as assigned_to
    //             ->join('tickets_departments', 'tickets_departments.id = department_id', 'left')  // Join with tickets_departments
    //             ->where('tickets.assigned_to = ', 'assigned_to')
    //             ->findAll();
    //     }
    // }

    public function getticketByassigned($role)
    {
        if ($role == 'super_admin') {
            // Super Admin can see all tickets
            return $this->select('tickets.*, requestor.username as requestor, assigned.username as assigned_to, tickets_departments.name as department')
                ->join('users as requestor', 'requestor.id = tickets.user_id')  // Join users as requestor
                ->join('users as assigned', 'assigned.id = tickets.assigned_to', 'left')  // Join users as assigned_to
                ->join('tickets_departments', 'tickets_departments.id = tickets.department_id', 'left')  // Join with tickets_departments
                ->where('tickets.assigned_to IS NOT NULL')

                ->findAll();
        }
    }
}
