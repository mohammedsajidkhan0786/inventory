<?php

namespace App\Models;

use CodeIgniter\Model;

class CannedReplyModel extends Model
{
    protected $table = 'canned_replies';  // Replace with your actual table name
    protected $primaryKey = 'id';
    protected $allowedFields = ['subject', 'message', 'created_by_role', 'updated_at', 'created_at'];

    // Fetch canned replies based on user role
    public function getCannedRepliesByRole($role)
    {
        if ($role == 'super_admin') {
            // Super Admin can see all canned replies
            return $this->findAll();
        } elseif ($role == 'agent') {
            // Agents see only their own canned replies
            return $this->where('created_by_role', 'agent')->findAll();
        } elseif ($role == 'user') {
            // Users see only their own canned replies
            return $this->where('created_by_role', 'user')->findAll();
        }

        return [];
    }
}
