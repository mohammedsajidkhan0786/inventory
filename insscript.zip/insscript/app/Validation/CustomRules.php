<?php

namespace App\Validation;

class CustomRules
{
    public function validHost(string $str, string &$error = null): bool
    {
        return (filter_var($str, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) !== false;
    }
}
