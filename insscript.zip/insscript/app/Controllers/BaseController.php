<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;
use App\Models\UserModel;

abstract class BaseController extends Controller
{
    protected $direction = 'ltr'; // Default direction is LTR

    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);

        // Set the language from the session or default to 'en'
        $language = session()->get('language') ?? 'en';

        // Set the direction based on the language
        $this->direction = ($language === 'ar') ? 'rtl' : 'ltr';

        // Set the locale for translations
        $this->setLocale($language);

        // if (session()->get('isLoggedIn')) {
        //     $userModel = new UserModel();
        //     $userId = session()->get('userId');

        //     // Update last_activity on every request
        //     $userModel->update($userId, ['last_activity' => time()]);

        //     // Also update the session last_activity
        //     session()->set('last_activity', time());
        // }
    }

    // Set the locale for the application
    protected function setLocale($language)
    {
        // Use CodeIgniter's built-in service to set the locale
        \Config\Services::language()->setLocale($language);
    }

    // Getter method for direction
    public function getDirection(): string
    {
        return $this->direction;
    }
}
