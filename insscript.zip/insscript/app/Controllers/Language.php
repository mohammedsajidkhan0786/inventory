<?php

namespace App\Controllers;

class Language extends BaseController
{
    public function switch($language = 'en')
    {
        // Set the active language in the session
        if (in_array($language, ['en', 'ar'])) {
            session()->set('language', $language);
        }

        // Redirect back to the previous page or home page
        return redirect()->back();
    }
}
