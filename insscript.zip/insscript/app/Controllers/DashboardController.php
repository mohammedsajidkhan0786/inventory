<?php

namespace App\Controllers;

use App\Models\TicketModel;
use App\Models\UserModel;
use App\Models\CannedReplyModel;

class DashboardController extends BaseController
{

    public function __construct()
    {

        $this->direction = 'ltr'; // Assuming you are using this somewhere in your view
    }
    public function index()
    {
        // Check if user is logged in
        if (!session()->get('isLoggedIn')) {
            return redirect()->to('/auth/login');
        }

        // Load the TicketModel
        $ticketModel = new TicketModel();
        $userModel = new UserModel();

        // Fetch ticket and user data
        $data['open_tickets'] = $ticketModel->getTotalOpenTickets();
        $data['closed_tickets'] = $ticketModel->getTotalClosedTickets();
        $data['total_tickets'] = $ticketModel->getTotalTickets();
        $data['total_users'] = $ticketModel->getTotalUsers();

        // Fetch recently registered users (limit 5)
        $data['recent_users'] = $userModel->getRecentlyRegisteredUsers();
        $data['direction'] = $this->direction;
        // Fetch monthly ticket statistics
        $monthlyTicketData = $ticketModel->getMonthlyTicketStats();

        // Prepare months array and ticket counts for the chart
        $months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        $ticketCounts = array_fill(0, 12, 0); // Initialize array with zeros for all 12 months

        foreach ($monthlyTicketData as $item) {
            // Set the ticket count for the respective month
            $ticketCounts[$item['month'] - 1] = $item['total'];
        }

        // Pass chart data to the view
        $data['months'] = $months;
        $data['ticketCounts'] = $ticketCounts;
        // Get user role from session
        $role = session()->get('role');

        // Load the appropriate dashboard view based on role
        if ($role == 'super_admin') {
            return view('admin/dashboard/admin', $data);
        } elseif ($role == 'agent') {
            return view('admin/dashboard/agent', $data);
        } elseif ($role == 'user') {
            return view('admin/dashboard/user', $data);
        }

        return redirect()->to('/auth/login');
    }

    // public function canned_replies()
    // {
    //     $d['direction'] = $this->direction;
    //     $role = session()->get('role');
    //     if ($role == 'super_admin') {
    //         return view('admin/dashboard/cannedReplies', $d);
    //     } elseif ($role == 'agent') {
    //         return view('admin/dashboard/agent');
    //     } elseif ($role == 'user') {
    //         return view('admin/dashboard/user');
    //     }
    // }

    public function canned_replies()
    {
        $d['direction'] = $this->direction;
        $role = session()->get('role');
        $CannedReplyModel = new CannedReplyModel();
        // Fetch the canned replies based on the role
        $d['canned_replies'] = $CannedReplyModel->getCannedRepliesByRole($role);

        $views = [
            'super_admin' => 'admin/dashboard/cannedReplies',
            'agent' => 'admin/dashboard/agent',
            'user' => 'admin/dashboard/user'
        ];

        if (array_key_exists($role, $views)) {
            return view($views[$role], $d);
        } else {
            return view('errors/role_not_found');
        }
    }

    public function getCannedReply($id)
    {
        $CannedReplyModel = new CannedReplyModel();
        $reply = $CannedReplyModel->find($id);
        return $this->response->setJSON($reply);
    }

    // public function canned_replies_add()
    // {
    //     // Validate the incoming data
    //     if ($this->request->getMethod() == 'post') {
    //         $rules = [
    //             'subject' => 'required|min_length[3]',
    //             'message' => 'required|min_length[5]',
    //         ];

    //         if (!$this->validate($rules)) {
    //             return $this->response->setJSON(['success' => false, 'errors' => $this->validator->getErrors()]);
    //         }

    //         // Save the data to the database
    //         $cannedReplyModel = new CannedReplyModel();
    //         $data = [
    //             'subject' => $this->request->getPost('subject'),
    //             'message' => $this->request->getPost('message'),
    //         ];

    //         echo "<pre>";
    //         print_r($data);
    //         die;

    //         if ($cannedReplyModel->insert($data)) {
    //             return $this->response->setJSON(['success' => true]);
    //         } else {
    //             return $this->response->setJSON(['success' => false, 'errors' => 'Database insert failed']);
    //         }
    //     }

    //     return $this->response->setJSON(['success' => false, 'errors' => 'Invalid request method']);
    // }

    // public function canned_replies_add()
    // {
    //     // Debugging: log or output the request method to ensure it is POST
    //     log_message('debug', 'Request Method: ' . $this->request->getMethod());

    //     // Check if the request method is POST
    //     if ($this->request->getMethod() === 'post') {
    //         // Define validation rules
    //         $rules = [
    //             'subject' => 'required|min_length[3]|max_length[255]',
    //             'message' => 'required|min_length[5]',
    //         ];

    //         // Validate the request data
    //         if (!$this->validate($rules)) {
    //             // Return validation errors
    //             return $this->response->setJSON([
    //                 'success' => false,
    //                 'errors' => $this->validator->getErrors()
    //             ]);
    //         }

    //         // Save the data to the database
    //         $cannedReplyModel = new CannedReplyModel();
    //         $data = [
    //             'subject' => $this->request->getPost('subject'),
    //             'message' => $this->request->getPost('message'),
    //         ];
    //         echo "<pre>";
    //         print_r($data);
    //         die;
    //         // Check if insert is successful
    //         if ($cannedReplyModel->insert($data)) {
    //             return $this->response->setJSON(['success' => true]);
    //         } else {
    //             return $this->response->setJSON(['success' => false, 'errors' => 'Database insert failed']);
    //         }
    //     }

    //     // If the method is not POST, return an error
    //     return $this->response->setJSON(['success' => false, 'errors' => 'Invalid request method']);
    // }

    // public function canned_replies_add()
    // {
    //     // Check if the request method is POST
    //     if ($this->request->getMethod() === 'post') {
    //         // Define validation rules
    //         $rules = [
    //             'subject' => 'required|min_length[3]|max_length[255]',
    //             'message' => 'required|min_length[5]',
    //         ];

    //         // Validate form inputs
    //         if (!$this->validate($rules)) {
    //             return $this->response->setJSON([
    //                 'success' => false,
    //                 'errors' => $this->validator->getErrors()
    //             ]);
    //         }

    //         // Save the data to the database
    //         $cannedReplyModel = new CannedReplyModel();
    //         $data = [
    //             'subject' => $this->request->getPost('subject'),
    //             'message' => $this->request->getPost('message'),
    //         ];

    //         if ($cannedReplyModel->insert($data)) {
    //             return $this->response->setJSON(['success' => true]);
    //         } else {
    //             return $this->response->setJSON(['success' => false, 'errors' => 'Database insert failed']);
    //         }
    //     }

    //     return $this->response->setJSON(['success' => false, 'errors' => 'Invalid request method']);
    // }

    public function  canned_replies_add()
    {
        // Check if the request method is POST
        if ($this->request->getMethod() === 'post') {
            // Define validation rules
            $rules = [
                'subject' => 'required|min_length[3]|max_length[255]',
                'message' => 'required|min_length[5]',
            ];

            // Validate form inputs
            if (!$this->validate($rules)) {
                // If validation fails, reload the page with validation errors
                return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
            }

            // Save the data to the database
            $cannedReplyModel = new CannedReplyModel();
            $data = [
                'subject' => $this->request->getPost('subject'),
                'message' => $this->request->getPost('message'),
            ];

            // If insert is successful, redirect with success message
            if ($cannedReplyModel->insert($data)) {
                return redirect()->back()->with('success', 'Canned Reply added successfully!');
            } else {
                return redirect()->back()->with('error', 'Database insert failed. Please try again.');
            }
        }

        // If the method is not POST, show error
        return redirect()->back()->with('error', 'Invalid request method');
    }




    public function TicketAll()
    {
        $d['direction'] = $this->direction;
        $role = session()->get('role');
        $TicketModels = new TicketModel();
        // Fetch the canned replies based on the role
        $d['ticket_all'] =  $TicketModels->getticketByRole($role);

        $views = [
            'super_admin' => 'admin/dashboard/ticketall',
            'agent' => 'admin/dashboard/agent',
            'user' => 'admin/dashboard/user'
        ];

        if (array_key_exists($role, $views)) {
            return view($views[$role], $d);
        } else {
            return view('errors/role_not_found');
        }
    }

    public function getticketReply($id)
    {
        $TicketModel = new TicketModel();
        $reply = $TicketModel->find($id);
        return $this->response->setJSON($reply);
    }


    public function TicketOpened()
    {
        $d['direction'] = $this->direction;
        $role = session()->get('role');
        $TicketModels = new TicketModel();
        // Fetch the canned replies based on the role
        $d['ticket_all'] =  $TicketModels->getticketByOpened($role);

        $views = [
            'super_admin' => 'admin/dashboard/ticketall',
            'agent' => 'admin/dashboard/agent',
            'user' => 'admin/dashboard/user'
        ];

        if (array_key_exists($role, $views)) {
            return view($views[$role], $d);
        } else {
            return view('errors/role_not_found');
        }
    }

    public function Ticketclosed()
    {
        $d['direction'] = $this->direction;
        $role = session()->get('role');
        $TicketModels = new TicketModel();
        // Fetch the canned replies based on the role
        $d['ticket_all'] =  $TicketModels->getticketByclose($role);

        $views = [
            'super_admin' => 'admin/dashboard/ticketall',
            'agent' => 'admin/dashboard/agent',
            'user' => 'admin/dashboard/user'
        ];

        if (array_key_exists($role, $views)) {
            return view($views[$role], $d);
        } else {
            return view('errors/role_not_found');
        }
    }

    public function Ticketassigned()
    {
        $d['direction'] = $this->direction;
        $role = session()->get('role');
        $TicketModels = new TicketModel();
        // Fetch the canned replies based on the role
        $d['ticket_all'] =  $TicketModels->getticketByassigned($role);

        $views = [
            'super_admin' => 'admin/dashboard/ticketall',
            'agent' => 'admin/dashboard/agent',
            'user' => 'admin/dashboard/user'
        ];

        if (array_key_exists($role, $views)) {
            return view($views[$role], $d);
        } else {
            return view('errors/role_not_found');
        }
    }

    public function TicketCreate()
    {
        $d['direction'] = $this->direction;
        $role = session()->get('role');
        $TicketModels = new TicketModel();
        // Fetch the canned replies based on the role
        $d['ticket_all'] =  $TicketModels->getticketByassigned($role);

        $views = [
            'super_admin' => 'admin/dashboard/ticketcreate',
            'agent' => 'admin/dashboard/agent',
            'user' => 'admin/dashboard/user'
        ];

        if (array_key_exists($role, $views)) {
            return view($views[$role], $d);
        } else {
            return view('errors/role_not_found');
        }
    }
}
