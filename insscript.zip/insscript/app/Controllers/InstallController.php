<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\Database\Config;
use Config\Database;
use Config\Services;

class InstallController extends BaseController
{
    // Entry point to the installation process
    public function index()
    {
        // First, check the system requirements
        return $this->checkRequirements();
    }

    // Step 1: Show the database configuration form
    public function step1()
    {
        return view('install/step1');
    }

    // Step 2: Perform file permission checks here
    public function step2()
    {
        return view('install/step2');
    }

    // Step 3: Create database tables, seed data, etc.
    // public function step3()
    // {
    // Table creation logic is handled in the view
    //     return view('install/step3');
    // }
    // public function step3()
    // {
    //     $migrations = Services::migrations();

    //     try {
    //         // Run all migrations
    //         $migrations->latest();

    //         // Show success message
    //         return view('install/step3', [
    //             'success' => true,
    //             'message' => 'Database tables created successfully.'
    //         ]);
    //     } catch (\Exception $e) {
    //         // Show error message
    //         return view('install/step3', [
    //             'success' => false,
    //             'message' => 'Failed to create database tables: ' . $e->getMessage()
    //         ]);
    //     }
    // }
    public function step3()
    {
        $migrations = Services::migrations();

        try {
            // Run all migrations
            $migrations->latest();

            // Check if the tables were newly created or already existed
            $db = \Config\Database::connect();
            $tableExists = $db->tableExists('users') && $db->tableExists('posts');

            if ($tableExists) {
                return view('install/step3', [
                    'success' => true,
                    'message' => 'The database tables already exist.'
                ]);
            } else {
                return view('install/step3', [
                    'success' => true,
                    'message' => 'Database tables created successfully.'
                ]);
            }
        } catch (\Exception $e) {
            // Show error message
            return view('install/step3', [
                'success' => false,
                'message' => 'Failed to create database tables: ' . $e->getMessage()
            ]);
        }
    }
    // Finalize installation process
    public function finalize()
    {
        return view('install/finalize');
    }

    // Configure database with user input
    // public function configureDatabase()
    // {
    //     // Define validation rules
    //     $validationRules = [
    //         'db_host' => [
    //             'label' => 'Database Host',
    //             'rules' => 'required',
    //             'errors' => [
    //                 'required' => 'The {field} is required.'
    //             ]
    //         ],
    //         'db_user' => [
    //             'label' => 'Database Username',
    //             'rules' => 'required',
    //             'errors' => [
    //                 'required' => 'The {field} is required.'
    //             ]
    //         ],
    //         'db_pass' => [
    //             'label' => 'Database Password',
    //             'rules' => 'permit_empty',
    //             'errors' => []
    //         ],
    //         'db_name' => [
    //             'label' => 'Database Name',
    //             'rules' => 'required',
    //             'errors' => [
    //                 'required' => 'The {field} is required.'
    //             ]
    //         ],
    //     ];

    //     // Validate the request
    //     if (!$this->validate($validationRules)) {
    //         return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    //     }

    //     // Logic to write database configuration from user input into .env
    //     $dbHost = $this->request->getPost('db_host');
    //     $dbUser = $this->request->getPost('db_user');
    //     $dbPass = $this->request->getPost('db_pass');
    //     $dbName = $this->request->getPost('db_name');

    //     // Update the .env file with user input
    //     $envPath = ROOTPATH . '.env';
    //     if (file_exists($envPath)) {
    //         $envContent = file_get_contents($envPath);
    //         $newContent = preg_replace('/database.default.hostname=.*/', "database.default.hostname=$dbHost", $envContent);
    //         $newContent = preg_replace('/database.default.database=.*/', "database.default.database=$dbName", $newContent);
    //         $newContent = preg_replace('/database.default.username=.*/', "database.default.username=$dbUser", $newContent);
    //         $newContent = preg_replace('/database.default.password=.*/', "database.default.password=$dbPass", $newContent);

    //         file_put_contents($envPath, $newContent);
    //     } else {
    //         // If .env file doesn't exist, create it
    //         $newContent = "database.default.hostname=$dbHost\n";
    //         $newContent .= "database.default.database=$dbName\n";
    //         $newContent .= "database.default.username=$dbUser\n";
    //         $newContent .= "database.default.password=$dbPass\n";

    //         file_put_contents($envPath, $newContent);
    //     }

    //     // Redirect to next step if successful
    //     return redirect()->to('/install/step2');
    // }
    // public function configureDatabase()
    // {
    //     // Define validation rules
    //     $validationRules = [
    //         'db_host' => [
    //             'label' => 'Database Host',
    //             'rules' => 'required',
    //             'errors' => [
    //                 'required' => 'The {field} is required.'
    //             ]
    //         ],
    //         'db_user' => [
    //             'label' => 'Database Username',
    //             'rules' => 'required',
    //             'errors' => [
    //                 'required' => 'The {field} is required.'
    //             ]
    //         ],
    //         'db_pass' => [
    //             'label' => 'Database Password',
    //             'rules' => 'permit_empty',
    //             'errors' => []
    //         ],
    //         'db_name' => [
    //             'label' => 'Database Name',
    //             'rules' => 'required',
    //             'errors' => [
    //                 'required' => 'The {field} is required.',
    //                 'checkDatabaseExists' => 'The {field} already exists.'
    //             ]
    //         ],
    //     ];

    //     // Validate the request
    //     if (!$this->validate($validationRules)) {
    //         // If validation fails, return to the form with errors
    //         return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    //     }

    //     // Proceed with your logic to configure the database
    //     $dbHost = $this->request->getPost('db_host');
    //     $dbUser = $this->request->getPost('db_user');
    //     $dbPass = $this->request->getPost('db_pass');
    //     $dbName = $this->request->getPost('db_name');

    //     // Update the .env file with user input
    //     $envPath = ROOTPATH . '.env';
    //     if (file_exists($envPath)) {
    //         $envContent = file_get_contents($envPath);
    //         $newContent = preg_replace('/database.default.hostname=.*/', "database.default.hostname=$dbHost", $envContent);
    //         $newContent = preg_replace('/database.default.database=.*/', "database.default.database=$dbName", $newContent);
    //         $newContent = preg_replace('/database.default.username=.*/', "database.default.username=$dbUser", $newContent);
    //         $newContent = preg_replace('/database.default.password=.*/', "database.default.password=$dbPass", $newContent);

    //         file_put_contents($envPath, $newContent);
    //     } else {
    //         // If .env file doesn't exist, create it
    //         $newContent = "database.default.hostname=$dbHost\n";
    //         $newContent .= "database.default.database=$dbName\n";
    //         $newContent .= "database.default.username=$dbUser\n";
    //         $newContent .= "database.default.password=$dbPass\n";

    //         file_put_contents($envPath, $newContent);
    //     }

    //     // Redirect to the next step if successful
    //     return redirect()->to('/install/step2');
    // }

    // public function configureDatabase()
    // {
    //     // Define validation rules
    //     $validationRules = [
    //         'db_host' => [
    //             'label' => 'Database Host',
    //             'rules' => 'required',
    //             'errors' => [
    //                 'required' => 'The {field} is required.'
    //             ]
    //         ],
    //         'db_user' => [
    //             'label' => 'Database Username',
    //             'rules' => 'required',
    //             'errors' => [
    //                 'required' => 'The {field} is required.'
    //             ]
    //         ],
    //         'db_pass' => [
    //             'label' => 'Database Password',
    //             'rules' => 'permit_empty',
    //         ],
    //         'db_name' => [
    //             'label' => 'Database Name',
    //             'rules' => 'required',
    //             'errors' => [
    //                 'required' => 'The {field} is required.'
    //             ]
    //         ],
    //     ];

    //     // Validate the request
    //     if (!$this->validate($validationRules)) {
    //         // If validation fails, return to the form with errors
    //         return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    //     }

    //     // Fetch user inputs from the form
    //     $dbHost = $this->request->getPost('db_host');
    //     $dbUser = $this->request->getPost('db_user');
    //     $dbPass = $this->request->getPost('db_pass');
    //     $dbName = $this->request->getPost('db_name');

    //     // Define the path to the .env file
    //     $envPath = ROOTPATH . '.env';

    //     // Check if the .env file exists
    //     if (file_exists($envPath)) {
    //         // Get the existing .env content
    //         $envContent = file_get_contents($envPath);

    //         // Replace database connection details with the new values from the form
    //         $newContent = preg_replace('/database.default.hostname=.*/', "database.default.hostname={$dbHost}", $envContent);
    //         $newContent = preg_replace('/database.default.username=.*/', "database.default.username={$dbUser}", $newContent);
    //         $newContent = preg_replace('/database.default.password=.*/', "database.default.password={$dbPass}", $newContent);
    //         $newContent = preg_replace('/database.default.database=.*/', "database.default.database={$dbName}", $newContent);

    //         // Write the updated content back to the .env file
    //         file_put_contents($envPath, $newContent);
    //     } else {
    //         // If the .env file doesn't exist, create it
    //         $newContent = "database.default.hostname={$dbHost}\n";
    //         $newContent .= "database.default.username={$dbUser}\n";
    //         $newContent .= "database.default.password={$dbPass}\n";
    //         $newContent .= "database.default.database={$dbName}\n";

    //         file_put_contents($envPath, $newContent);
    //     }

    //     // Redirect to the next step (e.g., file permission check)
    //     return redirect()->to('/install/step2');
    // }
    // public function configureDatabase()
    // {
    //     // Step 1: Define validation rules for user input
    //     $validationRules = [
    //         'db_host' => [
    //             'label' => 'Database Host',
    //             'rules' => 'required',
    //             'errors' => [
    //                 'required' => 'The {field} is required.'
    //             ]
    //         ],
    //         'db_user' => [
    //             'label' => 'Database Username',
    //             'rules' => 'required',
    //             'errors' => [
    //                 'required' => 'The {field} is required.'
    //             ]
    //         ],
    //         'db_pass' => [
    //             'label' => 'Database Password',
    //             'rules' => 'permit_empty',
    //         ],
    //         'db_name' => [
    //             'label' => 'Database Name',
    //             'rules' => 'required',
    //             'errors' => [
    //                 'required' => 'The {field} is required.'
    //             ]
    //         ],
    //     ];

    //     // Step 2: Validate the request
    //     if (!$this->validate($validationRules)) {
    //         // If validation fails, return to the form with errors
    //         return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    //     }

    //     // Step 3: Fetch user inputs from the form
    //     $dbHost = $this->request->getPost('db_host');
    //     $dbUser = $this->request->getPost('db_user');
    //     $dbPass = $this->request->getPost('db_pass');
    //     $dbName = $this->request->getPost('db_name');

    //     // Step 4: Check if the database exists
    //     try {
    //         // Attempt to connect to the MySQL server using provided credentials
    //         $mysqli = new \mysqli($dbHost, $dbUser, $dbPass);

    //         // Check if the connection was successful
    //         if ($mysqli->connect_errno) {
    //             // If there is a connection error, show an error message
    //             return redirect()->back()->withInput()->with('error', 'Database connection failed: ' . $mysqli->connect_error);
    //         }

    //         // Check if the database exists
    //         $dbExists = $mysqli->select_db($dbName);

    //         if (!$dbExists) {
    //             // If the database doesn't exist, return an error message
    //             return redirect()->back()->withInput()->with('error', 'The database "' . $dbName . '" does not exist.');
    //         }

    //         // Close the MySQL connection
    //         $mysqli->close();

    //         // Step 5: Define the path to the .env file
    //         $envPath = ROOTPATH . '.env';

    //         // Step 6: Check if the .env file exists
    //         if (file_exists($envPath)) {
    //             // Get the existing .env content
    //             $envContent = file_get_contents($envPath);

    //             // Replace database connection details with the new values from the form
    //             $newContent = preg_replace('/database.default.hostname=.*/', "database.default.hostname={$dbHost}", $envContent);
    //             $newContent = preg_replace('/database.default.username=.*/', "database.default.username={$dbUser}", $newContent);
    //             $newContent = preg_replace('/database.default.password=.*/', "database.default.password={$dbPass}", $newContent);
    //             $newContent = preg_replace('/database.default.database=.*/', "database.default.database={$dbName}", $newContent);

    //             // Write the updated content back to the .env file
    //             file_put_contents($envPath, $newContent);
    //         } else {
    //             // If the .env file doesn't exist, create it
    //             $newContent = "database.default.hostname={$dbHost}\n";
    //             $newContent .= "database.default.username={$dbUser}\n";
    //             $newContent .= "database.default.password={$dbPass}\n";
    //             $newContent .= "database.default.database={$dbName}\n";

    //             file_put_contents($envPath, $newContent);
    //         }

    //         // Step 7: Redirect to the next step (e.g., file permission check)
    //         return redirect()->to('/install/step2')->with('message', 'Database configuration updated successfully.');
    //     } catch (\Exception $e) {
    //         // Step 8: If there's any exception, return an error message
    //         return redirect()->back()->withInput()->with('error', 'An error occurred: ' . $e->getMessage());
    //     }
    // }
    // public function configureDatabase()
    // {
    //     // Step 1: Define validation rules
    //     $validationRules = [
    //         'db_host' => [
    //             'label' => 'Database Host',
    //             'rules' => 'required',
    //             'errors' => [
    //                 'required' => 'The {field} is required.'
    //             ]
    //         ],
    //         'db_user' => [
    //             'label' => 'Database Username',
    //             'rules' => 'required',
    //             'errors' => [
    //                 'required' => 'The {field} is required.'
    //             ]
    //         ],
    //         'db_pass' => [
    //             'label' => 'Database Password',
    //             'rules' => 'permit_empty',
    //         ],
    //         'db_name' => [
    //             'label' => 'Database Name',
    //             'rules' => 'required',
    //             'errors' => [
    //                 'required' => 'The {field} is required.'
    //             ]
    //         ],
    //     ];

    //     // Step 2: Validate the request
    //     if (!$this->validate($validationRules)) {
    //         // If validation fails, redirect back with input and errors
    //         return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    //     }

    //     // Step 3: Fetch user inputs from the form
    //     $dbHost = $this->request->getPost('db_host');
    //     $dbUser = $this->request->getPost('db_user');
    //     $dbPass = $this->request->getPost('db_pass');
    //     $dbName = $this->request->getPost('db_name');

    //     // Step 4: Check if the database exists
    //     try {
    //         // Try to establish a connection with the database
    //         $mysqli = new \mysqli($dbHost, $dbUser, $dbPass, $dbName);

    //         // Check for connection errors (including if the database doesn't exist)
    //         if ($mysqli->connect_errno) {
    //             // If there is a connection error, return an error message
    //             return redirect()->back()->withInput()->with('error', 'Could not connect to the database: ' . $mysqli->connect_error);
    //         }

    //         // Connection successful, close connection
    //         $mysqli->close();

    //         // Step 5: Update the .env file if the database exists
    //         $envPath = ROOTPATH . '.env';

    //         if (file_exists($envPath)) {
    //             // Get the existing .env content
    //             $envContent = file_get_contents($envPath);

    //             // Replace database connection details with the new values from the form
    //             $newContent = preg_replace('/database.default.hostname=.*/', "database.default.hostname={$dbHost}", $envContent);
    //             $newContent = preg_replace('/database.default.username=.*/', "database.default.username={$dbUser}", $newContent);
    //             $newContent = preg_replace('/database.default.password=.*/', "database.default.password={$dbPass}", $newContent);
    //             $newContent = preg_replace('/database.default.database=.*/', "database.default.database={$dbName}", $newContent);

    //             // Write the updated content back to the .env file
    //             file_put_contents($envPath, $newContent);
    //         } else {
    //             // If the .env file doesn't exist, create it
    //             $newContent = "database.default.hostname={$dbHost}\n";
    //             $newContent .= "database.default.username={$dbUser}\n";
    //             $newContent .= "database.default.password={$dbPass}\n";
    //             $newContent .= "database.default.database={$dbName}\n";

    //             file_put_contents($envPath, $newContent);
    //         }

    //         // Step 6: Redirect to the next step (e.g., file permission check)
    //         return redirect()->to('/install/step2')->with('message', 'Database configured successfully.');
    //     } catch (\Exception $e) {
    //         // If there's any exception, return an error message
    //         return redirect()->back()->withInput()->with('error', 'An error occurred: ' . $e->getMessage());
    //     }
    // }
    public function configureDatabase()
    {
        // Define validation rules
        $validationRules = [
            'db_host' => [
                'label' => 'Database Host',
                'rules' => 'required',
                'errors' => [
                    'required' => 'The {field} is required.'
                ]
            ],
            'db_user' => [
                'label' => 'Database Username',
                'rules' => 'required',
                'errors' => [
                    'required' => 'The {field} is required.'
                ]
            ],
            'db_pass' => [
                'label' => 'Database Password',
                'rules' => 'permit_empty',
            ],
            'db_name' => [
                'label' => 'Database Name',
                'rules' => 'required',
                'errors' => [
                    'required' => 'The {field} is required.'
                ]
            ],
        ];

        // Validate the request
        if (!$this->validate($validationRules)) {
            // If validation fails, redirect back with input and errors
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        // Fetch user inputs from the form
        $dbHost = $this->request->getPost('db_host');
        $dbUser = $this->request->getPost('db_user');
        $dbPass = $this->request->getPost('db_pass');
        $dbName = $this->request->getPost('db_name');

        // Try to connect to the database
        try {
            // Attempt to connect to the MySQL server using provided credentials
            $mysqli = new \mysqli($dbHost, $dbUser, $dbPass, $dbName);

            // Check for connection errors
            if ($mysqli->connect_errno) {
                // If there is a connection error, show an error message
                return redirect()->back()->withInput()->with('error', 'Could not connect to the database: ' . $mysqli->connect_error);
            }

            // Close connection after checking the database
            $mysqli->close();

            // Update the .env file logic goes here

            // Redirect to the next step (e.g., file permission check)
            return redirect()->to('/install/step2')->with('message', 'Database configured successfully.');
        } catch (\Exception $e) {
            // If there's an exception, return an error message
            return redirect()->back()->withInput()->with('error', 'An error occurred: ' . $e->getMessage());
        }
    }

    // System requirements check function
    public function checkRequirements()
    {
        $requirements = [];

        // Check PHP Version
        $phpVersion = PHP_VERSION;
        $requirements['php_version'] = [
            'label' => 'PHP v7.2+',
            'description' => 'Required Minimum 7.2 PHP Version',
            'status' => version_compare($phpVersion, '7.2.0', '>=') ? 'passed' : 'failed'
        ];

        // Check MySQLi extension
        $requirements['mysqli'] = [
            'label' => 'MySQLi',
            'description' => 'Required MySQLi PHP Extension',
            'status' => extension_loaded('mysqli') ? 'passed' : 'failed'
        ];

        // Check mbstring extension
        $requirements['mbstring'] = [
            'label' => 'mbstring',
            'description' => 'Required for UTF-8 Strings',
            'status' => extension_loaded('mbstring') ? 'passed' : 'failed'
        ];

        // Check GD Library extension
        $requirements['gd_library'] = [
            'label' => 'GD Library',
            'description' => 'Required for Image Processing',
            'status' => extension_loaded('gd') ? 'passed' : 'failed'
        ];

        // Check cURL extension
        $requirements['curl'] = [
            'label' => 'cURL',
            'description' => 'Required for APIs',
            'status' => extension_loaded('curl') ? 'passed' : 'failed'
        ];

        // Check ZipArchive extension
        $requirements['zip'] = [
            'label' => 'ZipArchive',
            'description' => 'Required for Backup Taking',
            'status' => extension_loaded('zip') ? 'passed' : 'failed'
        ];

        return view('install/requirements', ['requirements' => $requirements]);
    }
}
