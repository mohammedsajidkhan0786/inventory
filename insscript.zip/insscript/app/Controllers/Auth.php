<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    // public function login()
    // {
    //     helper(['form', 'url']);  // Load form and URL helpers

    //     // Load UserModel
    //     $userModel = new UserModel();

    //     // Check if it's an AJAX request
    //     if ($this->request->isAJAX()) {
    //         // Define validation rules
    //         $rules = [
    //             'email' => 'required|valid_email',  // Validation rule for email
    //             'password' => 'required|min_length[6]',  // Validation rule for password
    //         ];

    //         // Run validation
    //         if (!$this->validate($rules)) {
    //             // Return validation errors as JSON
    //             return $this->response->setJSON([
    //                 'status' => 'error',
    //                 'errors' => $this->validator->getErrors(),
    //             ]);
    //         } else {
    //             $emailOrUsername = $this->request->getPost('email');
    //             $password = $this->request->getPost('password');

    //             // Retrieve user by email or username
    //             $user = $userModel->getUserByEmailOrUsername($emailOrUsername);

    //             // Verify user exists and password matches
    //             if ($user && password_verify($password, $user['password'])) {
    //                 // Set user session
    //                 session()->set([
    //                     'isLoggedIn' => true,
    //                     'userId' => $user['id'],
    //                     'username' => $user['username'],
    //                     'email' => $user['email_address'],
    //                 ]);

    //                 // Return success as JSON
    //                 return $this->response->setJSON([
    //                     'status' => 'success',
    //                     'redirect' => site_url('dashboard'),  // Redirect URL
    //                 ]);
    //             } else {
    //                 // Return error for invalid credentials as JSON
    //                 return $this->response->setJSON([
    //                     'status' => 'error',
    //                     'message' => 'Invalid credentials, please try again.',
    //                 ]);
    //             }
    //         }
    //     }

    //     // Render the login form (non-AJAX request fallback)
    //     return view('auth/login');
    // }

    // public function login()
    // {
    //     helper(['form', 'url']);
    //     $userModel = new UserModel();

    //     if ($this->request->isAJAX()) {
    //         $rules = [
    //             'email' => 'required|valid_email',
    //             'password' => 'required|min_length[6]',
    //         ];

    //         if (!$this->validate($rules)) {
    //             return $this->response->setJSON([
    //                 'status' => 'error',
    //                 'errors' => $this->validator->getErrors(),
    //             ]);
    //         } else {
    //             $emailOrUsername = $this->request->getPost('email');
    //             $password = $this->request->getPost('password');

    //             $user = $userModel->getUserByEmailOrUsername($emailOrUsername);

    //             if ($user && password_verify($password, $user['password'])) {
    //                 session()->set([
    //                     'isLoggedIn' => true,
    //                     'userId' => $user['id'],
    //                     'username' => $user['username'],
    //                     'email' => $user['email_address'],
    //                     'role' => $user['role']
    //                 ]);

    //                 return $this->response->setJSON([
    //                     'status' => 'success',
    //                     'redirect' => site_url('dashboard'),
    //                 ]);
    //             } else {
    //                 return $this->response->setJSON([
    //                     'status' => 'error',
    //                     'message' => 'Invalid credentials, please try again.',
    //                 ]);
    //             }
    //         }
    //     }

    //     return view('auth/login');
    // }

    // public function login()
    // {
    //     helper(['form', 'url']);
    //     $userModel = new UserModel();

    //     if ($this->request->isAJAX()) {
    //         // Define validation rules
    //         $rules = [
    //             'email' => 'required', // No need for 'valid_email' as it can be either email or username
    //             'password' => 'required|min_length[6]',
    //         ];

    //         // Run validation
    //         if (!$this->validate($rules)) {
    //             // Return validation errors as JSON
    //             return $this->response->setJSON([
    //                 'status' => 'error',
    //                 'errors' => $this->validator->getErrors(),
    //             ]);
    //         } else {
    //             $emailOrUsername = $this->request->getPost('email'); // Accept either email or username
    //             $password = $this->request->getPost('password');

    //             // Retrieve user by email or username
    //             $user = $userModel->where('email_address', $emailOrUsername)
    //                 ->orWhere('username', $emailOrUsername)
    //                 ->first();

    //             // Check if user exists and password matches
    //             if ($user && password_verify($password, $user['password'])) {
    //                 // Set session
    //                 session()->set([
    //                     'isLoggedIn' => true,
    //                     'userId' => $user['id'],
    //                     'username' => $user['username'],
    //                     'email' => $user['email_address'],
    //                     'role' => $user['role'],
    //                 ]);

    //                 // Return success response
    //                 return $this->response->setJSON([
    //                     'status' => 'success',
    //                     'redirect' => site_url('dashboard'),
    //                 ]);
    //             } else {
    //                 // Return invalid credentials error
    //                 return $this->response->setJSON([
    //                     'status' => 'error',
    //                     'message' => 'Invalid credentials, please try again.',
    //                 ]);
    //             }
    //         }
    //     }

    //     // Render the login form for non-AJAX requests
    //     return view('auth/login');
    // }

    public function login()
    {
        helper(['form', 'url']);
        $userModel = new UserModel();

        if ($this->request->isAJAX()) {
            $rules = [
                'email' => 'required',
                'password' => 'required|min_length[6]',
            ];

            if (!$this->validate($rules)) {
                return $this->response->setJSON([
                    'status' => 'error',
                    'errors' => $this->validator->getErrors(),
                ]);
            } else {
                $emailOrUsername = $this->request->getPost('email');
                $password = $this->request->getPost('password');

                $user = $userModel->getUserByEmailOrUsername($emailOrUsername);
                $userModel->update($user['id'], ['last_activity' => time()]);
                if ($user && password_verify($password, $user['password'])) {
                    session()->set([
                        'isLoggedIn' => true,
                        'userId' => $user['id'],
                        'username' => $user['username'],
                        'email' => $user['email_address'],
                        'role' => $user['role_key'],  // Save role key in session
                        'role_name' => $user['role_name'], // Save readable role name in session
                        'last_activity' => time(),
                    ]);

                    return $this->response->setJSON([
                        'status' => 'success',
                        'redirect' => site_url('dashboard'),
                    ]);
                } else {
                    return $this->response->setJSON([
                        'status' => 'error',
                        'message' => 'Invalid credentials, please try again.',
                    ]);
                }
            }
        }

        //return view('auth/login');
        return view('admin/backend/pages/login', ['direction' => $this->direction]);
    }
    // public function logout()
    // {
    //     session()->destroy();  // Destroy session
    //     return redirect()->to('/auth/login');  // Redirect to login
    // }

    public function logout()
    {
        // Get the user's ID from the session
        $userId = session()->get('userId');

        // Update the user's last_activity to a past timestamp to make them offline
        $userModel = new \App\Models\UserModel();
        $userModel->update($userId, ['last_activity' => 0]);  // Setting last_activity to 0 or any past time

        // Destroy the session
        session()->destroy();

        // Redirect to the login page
        return redirect()->to('/auth/login');
    }
}
