<?php

return [
    'privacy' => [
        'heading' => 'Privacy Policy',
    ],
];
