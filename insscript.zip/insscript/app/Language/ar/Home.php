<?php

return [
    'privacy' => [
        'heading' => 'سياسة الخصوصية',
    ],
];
